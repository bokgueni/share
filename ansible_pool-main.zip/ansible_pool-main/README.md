# ansible_pool
훈련용 앤서블 작성
