import argparse
import os
import pathlib
import subprocess

from config import config
from services import service_ara, service_minio, service_periodic_runner, service_webhook
from utils import inventory
from utils.env import get_fabfile_env, get_playbook_env


def run_playbook(playbook_path: pathlib.Path, *extra_args):
    cwd = playbook_path.parent
    env = get_playbook_env()
    ssh_config_path = (config.CONFIG_DIR / 'ssh.cfg').as_posix()
    args = [
        'ansible-playbook', playbook_path.name,
        '-e', f"ansible_ssh_common_args='-F {ssh_config_path}'",
    ]
    if extra_args:
        args.extend(extra_args)
    subprocess.run(args, cwd=cwd.as_posix(), env=env)


def run_fabfile(fabfile_path: pathlib.Path):
    cwd = fabfile_path.parent
    env = get_fabfile_env()
    subprocess.run(['fab', 'deploy'], cwd=cwd.as_posix(), env=env)


def main():
    env_choices = []
    for path in (config.PROJECT_ROOT / 'inventory').iterdir():
        if path.stem.startswith('_') or not os.path.isdir(path):
            continue
        env_choices.append(os.path.basename(path))

    services = {
        'all': [service_ara, service_webhook, service_minio, service_periodic_runner],
        'ara': service_ara,
        'webhook': service_webhook,
        'periodic-runner': service_periodic_runner,
        'minio': service_minio,
    }

    parser = argparse.ArgumentParser()
    parser.add_argument('--env', dest='env', metavar='ENV',
                        choices=env_choices,
                        default=config.env)
    # parser.add_argument('-f', '--foreground', dest='foreground', action='store_true')
    # parser.add_argument('-r', '--rebuild', dest='rebuild', action='store_true')
    parser.add_argument('command', metavar='start|stop|play|run', nargs='?',
                        default='', choices=['', 'start', 'stop', 'play'])
    parser.add_argument('target', metavar='target', nargs='?', default='')
    args, extra_args = parser.parse_known_args()

    os.environ.update(ENV=args.env)
    config.update_ansible_config()
    inventory.create_jump_points_ssh_config()

    if not args.command or not args.target:
        return

    # if args.command in ['start', 'stop']:
    #     config.assert_service_config()
    #     service = services.get(args.target)
    #     if args.target == 'all':
    #         for srv in service:
    #             srv(args.command, rebuild=args.rebuild)
    #     elif service is not None:
    #         service(args.command, foreground=args.foreground, rebuild=args.rebuild)
    #     else:
    #         print(f'Unknown service: {args.target}')
    if args.command == 'play':
        target_path = pathlib.Path(args.target).resolve()
        assert target_path.exists(), f"{target_path} does not exists"
        if 'ansible' in target_path.parts:
            run_playbook(target_path, *extra_args)
        elif 'fabric' in target_path.parts:
            run_fabfile(target_path)


if __name__ == '__main__':
    main()
