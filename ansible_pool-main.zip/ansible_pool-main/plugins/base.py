from ansible.plugins.action import ActionBase

from utils.file import create_minio_client


class MinIOActionBase(ActionBase):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.client = create_minio_client()
        self.target_is_windows = False

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        for arg in self._task.args:
            if arg not in self._VALID_ARGS:
                result = {'failed': True, 'msg': '{0} is not a valid option.'.format(arg)}
                return result

        result = super().run(tmp, task_vars)
        if result.get('failed'):
            return result

        self.target_is_windows = 'windows' in task_vars.get('family', '').lower()

        return result
