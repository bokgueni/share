import os
from concurrent.futures import ThreadPoolExecutor

from ansible import __version__ as ansible_version, context
from ansible.plugins.callback import CallbackBase
from ara.clients import utils as client_utils
from ara.plugins.callback import ara_default

from utils.common import tz_now
from utils.git import get_username

cli_options = {key: value for key, value in context.CLIARGS.items()}


class CallbackModule(ara_default.CallbackModule):

    def __init__(self):
        super().__init__()
        self.argument_labels = []
        self.default_labels = []
        self._plugin_options = dict(
            display_skipped_hosts=True,
            display_ok_hosts=True,
            show_custom_stats=False,
            display_failed_stderr=False,
            check_mode_markers=False,
            show_per_host_start=False,
            argument_labels=['remote_user', 'check', 'tags', 'skip_tags', 'subset'],
            default_labels=[],
            ignored_facts=['ansible_env'],
            ignored_arguments=['extra_vars'],
            ignored_files=[],
            localhost_as_hostname=True,
            localhost_as_hostname_format='hostname',
            api_client=os.getenv('ARA_API_CLIENT'),
            api_server=os.getenv('ARA_API_SERVER'),
            api_timeout=30,
            api_username=None,
            api_password=None,
            api_insecure=False,
            callback_threads=0,
        )

    def set_options(self, task_keys=None, var_options=None, direct=None):
        super(CallbackBase, self).set_options(task_keys=task_keys, var_options=var_options,
                                              direct=direct)
        self.argument_labels = self.get_option("argument_labels")
        self.default_labels = self.get_option("default_labels")
        self.ignored_facts = self.get_option("ignored_facts")
        self.ignored_arguments = self.get_option("ignored_arguments")
        self.ignored_files = self.get_option("ignored_files")
        self.localhost_as_hostname = self.get_option("localhost_as_hostname")
        self.localhost_as_hostname_format = self.get_option("localhost_as_hostname_format")

        client = self.get_option("api_client")
        endpoint = self.get_option("api_server")
        timeout = self.get_option("api_timeout")
        username = self.get_option("api_username")
        password = self.get_option("api_password")
        insecure = self.get_option("api_insecure")
        self.client = client_utils.get_client(
            client=client,
            endpoint=endpoint,
            timeout=timeout,
            username=username,
            password=password,
            verify=False if insecure else True,
        )

    def v2_playbook_on_start(self, playbook):
        self.log.debug("v2_playbook_on_start")
        self.localhost_hostname = get_username() or self._get_localhost_hostname()

        if self.callback_threads:
            self.global_threads = ThreadPoolExecutor(max_workers=self.callback_threads)
            self.log.debug(
                "Global thread pool initialized with %s thread(s)" % self.callback_threads)

        content = None

        if playbook._file_name == "__adhoc_playbook__":
            content = cli_options["module_name"]
            if cli_options["module_args"]:
                content = "{0}: {1}".format(content, cli_options["module_args"])
            path = "Ad-Hoc: {0}".format(content)
        else:
            path = os.path.abspath(playbook._file_name)

        # Potentially sanitize some user-specified keys
        for argument in self.ignored_arguments:
            if argument in cli_options:
                self.log.debug("Ignoring argument: %s" % argument)
                cli_options[argument] = "Not saved by ARA as configured by 'ignored_arguments'"

        # Retrieve and format CLI options for argument labels
        argument_labels = []
        for label in self.argument_labels:
            if label in cli_options:
                # Some arguments are lists or tuples
                if isinstance(cli_options[label], tuple) or isinstance(cli_options[label], list):
                    # Only label these if they're not empty
                    if cli_options[label]:
                        argument_labels.append("%s:%s" % (label, ",".join(cli_options[label])))
                # Some arguments are booleans
                elif isinstance(cli_options[label], bool):
                    argument_labels.append("%s:%s" % (label, cli_options[label]))
                # The rest can be printed as-is if there is something set
                elif cli_options[label]:
                    argument_labels.append("%s:%s" % (label, cli_options[label]))
        self.argument_labels = argument_labels

        name = os.path.join('/'.join(os.path.dirname(path).split('/')[-2:]))
        common_args = dict(name=name, ansible_version=ansible_version)
        args = dict(arguments=cli_options, status='running', controller=self.localhost_hostname,
                    started=tz_now(), path=path)
        res = self.client.get('/api/v1/playbooks', **common_args)
        if res['count'] == 0:
            self.playbook = self.client.post("/api/v1/playbooks", **common_args, **args)
        else:
            playbook_id = res['results'][0]['id']
            self.playbook = self.client.patch(f'/api/v1/playbooks/{playbook_id}', **args)

        # Record the playbook file
        self._submit_thread("global", self._get_or_create_file, path, content)

        return self.playbook

    def _get_or_create_file(self, path, content=None):
        if path not in self.file_cache:
            self.log.debug("File not in cache, getting or creating: %s" % path)
            for ignored_file_pattern in self.ignored_files:
                if ignored_file_pattern in path:
                    self.log.debug(
                        "Ignoring file {1}, matched pattern: {0}".format(ignored_file_pattern, path)
                    )
                    content = "Not saved by ARA as configured by 'ignored_files'"
            if content is None:
                try:
                    with open(path, "r") as fd:
                        content = fd.read()
                except IOError as e:
                    self.log.error("Unable to open {0} for reading: {1}".format(path, str(e)))
                    content = """ARA was not able to read this file successfully.
                            Refer to the logs for more information"""

            res = self.client.get('/api/v1/files', playbook=self.playbook['id'], path=path)
            if res['count'] == 0:
                file = self.client.post(
                    '/api/v1/files',
                    playbook=self.playbook['id'], path=path, content=content,
                )
            else:
                file_id = res['results'][0]['id']
                file = self.client.patch(
                    f'/api/v1/files/{file_id}',
                    playbook=self.playbook['id'], path=path, content=content,
                )
            self.file_cache[path] = file

        return self.file_cache[path]
