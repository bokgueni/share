import os
import pathlib
import shutil
import tempfile

from ansible.module_utils.parsing.convert_bool import boolean
from ansible.plugins.action import copy
from ansible_collections.ansible.windows.plugins.action import win_copy

from config import config
from plugins.base import MinIOActionBase
from utils.file import create_minio_client, update_minio_bucket


def get_download_info(src, dest, **kwargs):
    client = create_minio_client()
    bucket = kwargs.get('bucket', config.MINIO_DEFAULT_BUCKET_NAME)
    directory_mode = kwargs.get('directory_mode', False)

    sources = []
    if directory_mode:
        for obj in client.list_objects(bucket, prefix=src, recursive=True):
            sources.append(obj.object_name)
    else:
        res = client.get_object(bucket, src)
        if res.status == 200:
            sources.append(src)

    info = []
    host = config.minio_raw_endpoint
    for source in sources:
        path = os.path.join(bucket, source)
        if directory_mode:
            dest_path = os.path.join(dest, source.replace(src, '').strip('/'))
        else:
            dest_path = dest
        info.append(dict(url=f'{host}/{path}', dest=dest_path))
    return info


def minio_copy_to_local(**kwargs):
    client = create_minio_client()
    bucket = kwargs.get('bucket', config.MINIO_DEFAULT_BUCKET_NAME)
    src = kwargs['src']
    directory_mode = kwargs.get('directory_mode', False)

    update_minio_bucket(client, bucket)

    if directory_mode:
        temp_dir = os.path.join(tempfile.mkdtemp(), os.path.basename(src))
        for obj in client.list_objects(bucket, recursive=True, prefix=src):
            object_name = obj.object_name.replace(src, '').lstrip('/')
            object_dir = os.path.join(temp_dir, os.path.dirname(object_name))
            local_object_path = os.path.join(temp_dir, object_name)
            os.makedirs(object_dir, exist_ok=True)
            client.fget_object(bucket, obj.object_name, local_object_path)
        src = temp_dir
    else:
        temp_dir = tempfile.mkdtemp()
        temp_path = os.path.join(temp_dir, os.path.basename(src))
        client.fget_object(bucket, src, temp_path)
        src = temp_path

    return src


class ActionModule(MinIOActionBase):
    TRANSFERS_FILES = False
    _VALID_ARGS = frozenset([
        'bucket',
        'src',
        'dest',
        'directory_mode',
        'force',
        'mode',
    ])

    def run(self, tmp=None, task_vars=None):
        result = super(ActionModule, self).run(tmp, task_vars)
        if result.get('failed'):
            return result

        bucket = self._task.args.get('bucket', config.MINIO_DEFAULT_BUCKET_NAME)
        src = self._task.args.get('src', None)
        dest = self._task.args.get('dest', None)
        directory_mode = boolean(self._task.args.get('directory_mode', None), strict=False)
        force = boolean(self._task.args.get('force', 'yes'), strict=False)
        mode = self._task.args.get('mode', None)

        result.update(bucket=bucket, src=src, dest=dest, failed=True)
        if src is None:
            result['msg'] = 'src is required'
        elif dest is None:
            result['msg'] = 'dest is required'
        else:
            del result['failed']

        if result.get('failed'):
            return result

        uri_module = 'win_uri' if self.target_is_windows else 'uri'
        uri_return = self._execute_module(
            uri_module,
            module_args=dict(url=config.minio_raw_endpoint, method='OPTIONS', timeout=5),
            task_vars=task_vars,
        )
        status = uri_return.get('status') or uri_return.get('status_code')
        wget_usable = status == 200
        if wget_usable:
            fails = []
            info = get_download_info(src, dest, bucket=bucket, directory_mode=directory_mode)
            file_module = 'win_file' if self.target_is_windows else 'file'
            for data in info:
                path = pathlib.Path(data['dest'])
                if len(path.parts) == 1:
                    continue
                self._execute_module(
                    file_module,
                    module_args=dict(path=os.path.dirname(data['dest']), state='directory'),
                    task_vars=task_vars,
                )

            get_url_module = 'win_get_url' if self.target_is_windows else 'get_url'
            files = []
            for data in info:
                get_url_return = self._execute_module(
                    get_url_module,
                    module_args=dict(url=data['url'], dest=data['dest'], force=force),
                    task_vars=task_vars,
                )
                if get_url_return.get('failed'):
                    fails.append(get_url_return)
                files.append(data['dest'])

            if fails:
                result.update(failed=True, fails=fails)
                return result

            result.update(operation='minio_copy', files=files)
            return result

        src = minio_copy_to_local(bucket=bucket, src=src, directory_mode=directory_mode)
        org_src = self._task.args['src']
        self._task.args = dict(src=src, dest=dest, force=force)
        if not self.target_is_windows:
            self._task.args.update(directory_mode=directory_mode, mode=mode)

        copy_action_cls = win_copy if self.target_is_windows else copy
        copy_action = copy_action_cls.ActionModule(
            self._task,
            self._connection,
            self._play_context,
            self._loader,
            self._templar,
            self._shared_loader_obj,
        )
        action_return = copy_action.run(tmp, task_vars)

        shutil.rmtree(os.path.dirname(src), ignore_errors=True)
        result.update(
            action_return,
            src=org_src,
            original_basename=os.path.basename(org_src),
            operation='minio_copy_to_local',
        )
        if result.get('failed'):
            return result

        return result
