import mimetypes
import os
import pathlib
import shutil
import subprocess
import tempfile
from concurrent.futures import ProcessPoolExecutor, as_completed

from ansible.module_utils.parsing.convert_bool import boolean

from config import config
from plugins.base import MinIOActionBase
from utils.file import create_minio_client, scp_copy

REQUIRED_ARGS = frozenset(['src', 'dest'])
VALID_ARGS = frozenset([
    *REQUIRED_ARGS,
    'bucket',
    'flat',
    'directory_mode',
    'base',
    'glob',
    'clean',
])


def make_find_args_by_pattern(pattern: str, is_windows: bool):
    if is_windows:
        path = pathlib.PureWindowsPath(pattern)
    else:
        path = pathlib.PurePosixPath(pattern)

    min_index = len(path.parts) - 1
    for i, part in enumerate(path.parts):
        if '*' in part and i < min_index:
            min_index = i

    base = os.path.join(*path.parts[:min_index])
    pattern = os.path.join(*path.parts[min_index:])
    return dict(paths=[base], patterns=[pattern])


def minio_fetch_to_minio(base, sources, dest, **kwargs):
    client = create_minio_client()
    bucket = kwargs.get('bucket', config.MINIO_DEFAULT_BUCKET_NAME)
    flat = kwargs.get('flat', False)
    clean = kwargs.get('clean', True)

    if not sources:
        return dict(failed=True, reason="'sources' cannot be empty.")
    if not os.path.isdir(base):
        return dict(failed=True, reason="'base' must be a directory.")

    fails = []
    objects = []
    for src in sources:
        _path = src.replace(base, '').strip('/')
        if flat:
            object_name = os.path.join(dest, os.path.basename(src))
        else:
            p = pathlib.Path(_path)
            if len(p.parts) > 1 and p.parts[-1] == p.parts[-2]:
                object_name = os.path.join(*p.parts[:-1])
            else:
                object_name = os.path.join(dest, os.path.basename(_path))
        content_type, _ = mimetypes.guess_type(src)

        try:
            client.fput_object(bucket, object_name, src, content_type=content_type)
            objects.append(dict(local_path=src, key=object_name))
        except Exception as e:
            fails.append(dict(
                local_path=src,
                key=os.path.join(bucket, object_name),
                error=str(e),
            ))

    if clean and base.startswith(tempfile.gettempdir()):
        shutil.rmtree(base)

    return dict(failed=len(fails) > 0, objects=objects, fails=fails)


class ActionModule(MinIOActionBase):
    TRANSFERS_FILES = False
    _VALID_ARGS = frozenset([
        'src',
        'bucket',
        'dest',
        'flat',
        'glob',
    ])

    def run(self, tmp=None, task_vars=None):
        result = {}
        src = self._task.args.get('src', None)
        bucket = self._task.args.get('bucket', config.MINIO_DEFAULT_BUCKET_NAME)
        dest = self._task.args.get('dest', None)
        flat = boolean(self._task.args.get('flat', 'no'), strict=False)

        result.update(bucket=bucket, src=src, dest=dest, operation='minio_get', failed=True)
        if src is None:
            result['msg'] = 'src is required'
        elif dest is None:
            result['msg'] = 'dest is required'
        else:
            del result['failed']

        if result.get('failed'):
            return result

        temp_dir = tempfile.mkdtemp()
        stat_module = 'win_stat' if self.target_is_windows else 'stat'
        stat_return = self._execute_module(
            stat_module,
            module_args=dict(path=src, follow=True),
            task_vars=task_vars,
        )
        stat = stat_return['stat']
        if stat['exists']:
            remote_files = [dict(path=src, isdir=stat['isdir'])]
        else:
            find_module = 'win_find' if self.target_is_windows else 'find'
            find_args = make_find_args_by_pattern(src, self.target_is_windows)
            find_return = self._execute_module(
                find_module,
                module_args=find_args,
                task_vars=task_vars,
            )
            result.update(find_return, operation=f'minio_get:{find_module}')
            if result.get('failed'):
                return result

            remote_files = find_return['files']

        pool = ProcessPoolExecutor(max_workers=4)
        futures = []
        for file in remote_files:
            fs = pool.submit(
                scp_copy,
                file['path'],
                temp_dir,
                config.DEFAULT_SSH_KEY_PATH.as_posix(),
                task_vars['ansible_host'],
                task_vars['ansible_port'],
                task_vars['ansible_user'],
                directory_mode=file['isdir'],
                fetch=True,
            )
            futures.append(fs)

        fails = []
        result.update(operation='minio_get:scp', failed=True)
        for fs in as_completed(futures):
            p = fs.result()
            if isinstance(p, subprocess.SubprocessError):
                fails.append(dict(error=str(p)))
            elif p.returncode != 0:
                fails.append(dict(cmd=' '.join(p.args), stderr=p.stderr))

        if fails:
            result.update(failed=True, fails=fails)
            return result
        del result['failed']

        sources = []
        for root, dirs, files in os.walk(temp_dir):
            sources.extend(map(lambda f: os.path.join(root, f), files))

        has_same_basename = os.path.basename(src) == os.path.basename(dest)
        if has_same_basename:
            dest = os.path.dirname(dest)

        fetch_return = minio_fetch_to_minio(
            temp_dir,
            sources,
            dest,
            bucket=bucket,
            flat=flat,
        )
        if fetch_return is not None:
            result.update(fetch_return)

        result.update(operation='minio_get')
        return result
