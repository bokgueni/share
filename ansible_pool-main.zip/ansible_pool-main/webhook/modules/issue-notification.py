import re
import threading
from typing import Any, Dict, List

from config import config
from utils.git import get_gitlab_client
from utils.slack import get_slack_client

CC_RE = re.compile(r'/cc (.*)')
gitlab_cli = get_gitlab_client()
slack_cli = get_slack_client()
_slack_ids_by_username = {}
_slack_ids_by_gid = {}
_channel_ids_by_name = {}


def init():
    global _slack_ids_by_username
    global _channel_ids_by_name
    gitlab_users = {}
    slack_users = {}

    for u in gitlab_cli.users.list():
        if u.id in _slack_ids_by_gid:
            continue
        gitlab_users[u.id] = dict(email=u.email, id=u.id, username=u.username)

    # if there exists new gitlab users, update it with slack user info
    if gitlab_users:
        res = slack_cli.users_list()
        for u in res['members']:
            if u['is_bot'] or not u.get('is_email_confirmed', False):
                continue
            profile = u['profile']
            slack_users[u['id']] = dict(email=profile['email'])

        for s_uid, s_user in slack_users.items():
            for g_uid, g_user in gitlab_users.items():
                if s_user['email'] == g_user['email']:
                    _slack_ids_by_gid[g_user['id']] = s_uid
                    _slack_ids_by_username[g_user['username']] = s_uid
                    break

    res = slack_cli.conversations_list()
    for ch in res['channels']:
        _channel_ids_by_name[ch['name']] = ch['id']


def get_slack_channel(name: str):
    return _channel_ids_by_name.get(name, None)


def get_slack_user(*, username: str = None, gid: int = None):
    if username is not None:
        return _slack_ids_by_username.get(username, None)
    elif gid is not None:
        return _slack_ids_by_gid.get(gid, None)
    return None


def extract_mentions(text: str):
    mentions = set()
    for line in text.splitlines():
        if not line.strip():
            continue

        i = 0
        off = 0
        while (i := line[off + i:].find('/cc')) != -1:
            res = CC_RE.findall(line[off + i:])
            if not res:
                continue
            for mention in res:
                mentions.update(mention.split())
            off = i + 4
    return list(mentions)


def get_new_labels(params, new=False):
    return list(map(lambda l: l['title'], params['labels']))


def get_new_mentions(params):
    return extract_mentions(params['object_attributes']['description'])


def labels_to_slack_channels(labels: List[Dict[str, Any]]):
    channels = set()
    for label in labels:
        title = label['title']
        if title.startswith('ch::'):
            _, channel_name = title.split('::', 1)
            channel = get_slack_channel(channel_name)
            if channel is not None:
                channels.add(channel)
    return channels


def mentions_to_slack_users(text: str):
    users = set()
    mentions = extract_mentions(text)
    if not mentions:
        return users

    for mention in mentions:
        username = mention.strip('@')
        user = get_slack_user(username=username)
        if user is not None:
            users.add(user)

    return users


def post_message(blocks, channels=None, users=None):
    if channels is None:
        channels = []
    if users is None:
        users = []

    for channel in channels:
        slack_cli.chat_postMessage(channel=channel, blocks=blocks)
    for user in sorted(users):
        res = slack_cli.conversations_open(users=user)
        dm_channel = res['channel']['id']
        slack_cli.chat_postMessage(channel=dm_channel, blocks=blocks)


def handle_issue(params):
    issue = params['object_attributes']
    action = issue['action']
    if action != 'open':
        return

    channels = labels_to_slack_channels(issue['labels'])
    users = mentions_to_slack_users(issue['description'])

    issuer = _slack_ids_by_gid[params['user']['id']]
    assignee = issue['assignee_id']
    if assignee is not None:
        assignee = _slack_ids_by_gid[assignee]
        users.add(assignee)

    title = f"*<{issue['url']}|Issue#{issue['id']} - {issue['title']}>*"
    if assignee is None or issuer == assignee:
        text = f"<@{issuer}> created an issue"
    else:
        text = f"<@{issuer}> assigned an issue to <@{assignee}>."

    if users:
        ref_users = ' '.join(map(lambda u: f'<@{u}>', users))
        text += f"\n\n/cc {ref_users}"
    if issue['labels']:
        labels = ' '.join(map(lambda l: f"`{l['title']}`", issue['labels']))
        text += f"\n\n/labels *{labels}*"

    blocks = [
        dict(type='section', text=dict(type='mrkdwn', text=title)),
        dict(type='section', text=dict(type='mrkdwn', text=text)),
    ]

    post_thread = threading.Thread(
        target=post_message,
        args=(blocks,),
        kwargs=dict(channels=channels, users=users),
    )
    post_thread.start()


def handle_comment(params):
    issue = params['issue']
    comment = params['object_attributes']
    users = mentions_to_slack_users(comment['description'])
    author = _slack_ids_by_gid[comment['author_id']]
    text = f"<@{author}> mentioned you in <{comment['url']}|Issue#{issue['id']}>"
    blocks = [
        dict(type='section', text=dict(type='mrkdwn', text=text)),
        dict(type='section', text=dict(type='mrkdwn', text=f"```{comment['description']}```")),
    ]
    threading.Thread(target=post_message, args=(blocks,), kwargs=dict(users=users)).start()

    if issue['assignee_id'] is not None:
        assignee = _slack_ids_by_gid[issue['assignee_id']]
        if assignee in users:
            return

        title = f"<@{author}> left a comment for <{comment['url']}|Issue#{issue['id']}>"
        blocks = [
            dict(type='section', text=dict(type='mrkdwn', text=title)),
            dict(type='section', text=dict(type='mrkdwn', text=f"```{comment['description']}```")),
        ]
        threading.Thread(target=post_message, args=(blocks,), kwargs=dict(users=[assignee])).start()


def main(token, params, request, logger):
    if token != config.ISSUE_NOTIFICATION_TOKEN:
        return request.send_response(403, 'Not Authorized')

    init()

    kind = params.get('object_kind', None)
    if kind is None:
        return request.send_response(400, 'Bad Request')

    if kind == 'issue':
        handle_issue(params)
    elif kind == 'note':
        handle_comment(params)
    else:
        logger.info(f'Not supported kind: {kind}')

    return request.send_response(200, 'OK')
