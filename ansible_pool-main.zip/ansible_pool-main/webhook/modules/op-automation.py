import glob
import os
import subprocess
from http.server import BaseHTTPRequestHandler
from logging import Logger
from typing import Any, Dict

from config import config
from utils.env import get_playbook_env, get_fabfile_env
from utils.inventory import create_jump_points_ssh_config
from utils.slack import send_webhook_debug_message


def update_repository(params):
    current_ref = params['before']
    checkout_ref = params['checkout_sha']
    os.chdir(config.PROJECT_ROOT)

    p = subprocess.run(['git', 'checkout', '.'])
    if p.returncode != 0:
        return 500, f"Failed to reset changes"

    p = subprocess.run(['git', 'fetch'], stdout=subprocess.DEVNULL)
    if p.returncode != 0:
        return 500, f"Failed to fetch"

    p = subprocess.run(['git', 'checkout', checkout_ref])
    if p.returncode != 0:
        return 500, f"Failed to checkout from {current_ref} to {checkout_ref}"

    return 200, 'OK'


def fix_ssh_private_key_permission():
    os.chmod(config.DEFAULT_SSH_KEY_PATH, 0o400)


class BasicTaskAutomation:
    def __init__(
        self, token: str, params: dict[str, any], request: BaseHTTPRequestHandler,
        logger: Logger
    ):
        self.token = token
        self.params = params
        self.request = request
        self.logger = logger
        self.status = 200, 'OK'
        self._handlers = {
            'ansible': self.handle_ansible,
            'fabric': self.handle_fabric,
        }

    @property
    def commits(self):
        for commit in self.params['commits']:
            title = commit['title']
            m = config.AUTOMATION_WEBHOOK_RULE.match(title)
            if m is None:
                self.logger.info(f"TASK SKIPPED: {title}")
                continue
            yield commit, m.groupdict()

    def setup(self):
        if self.token != config.AUTOMATION_WEBHOOK_TOKEN:
            self.status = 401, "Token not recognized"
            return

        code, message = update_repository(self.params)
        if code != 200:
            self.status = code, message
            return

        fix_ssh_private_key_permission()

    def validate(self):
        return self.status[0] == 200

    def handle(self):
        self.setup()
        if not self.validate():
            return self.request.send_response(*self.status)

        for commit, res in self.commits:
            title = commit['title']
            self.logger.info(f"TASK ACCEPTED: {title}")
            typ = res['type']
            no = res['no']
            task_dir_p = config.PROJECT_ROOT / 'operation' / typ / f'{no}*'
            res = glob.glob(task_dir_p.as_posix())
            if not res:
                message = f"Could not find task directory from commit title"
                return self.request.send_response(403, message)

            task_dir = res[0]
            ret = self._handlers[typ](task_dir, commit)

            if ret != 0:
                message = f"Exception occurred in {title}: ret_code={ret}"
                self.logger.info(message)
                return self.request.send_response(403, message)

        self.request.send_response(200, 'OK')

    def handle_ansible(self, task_dir: str, commit: Dict[str, Any]):
        playbook_path = os.path.join(task_dir, 'playbook.yml')
        if not os.path.exists(playbook_path):
            return 1

        ssh_config_path = create_jump_points_ssh_config()
        labels = ','.join(self.extract_labels_from_title('ansible', commit['title']))
        env = get_playbook_env()
        args = [
            'ansible-playbook',
            playbook_path,
            '-e', f'ara_playbook_labels={labels}',
            '-e', f"ansible_ssh_common_args='-F {ssh_config_path}'",
        ]
        try:
            p = subprocess.run(args, env=env, cwd=task_dir)
        except Exception as e:
            send_webhook_debug_message(commit, 'ansible', e)
            return 1
        return p.returncode

    def handle_fabric(self, task_dir: str, commit: Dict[str, Any]):
        fabfile_path = os.path.join(task_dir, 'fabfile.py')
        if not os.path.exists(fabfile_path):
            return 1

        labels = ','.join(self.extract_labels_from_title('fabric', commit['title']))
        env = get_fabfile_env()
        env.update(LABELS=labels, COMMIT_TITLE=commit['title'])
        try:
            p = subprocess.run(['fab', '-r', task_dir, 'deploy'], env=env, cwd=task_dir)
        except Exception as e:
            send_webhook_debug_message(commit, 'fabric', e)
            return 1
        return p.returncode

    @staticmethod
    def extract_labels_from_title(typ, title):
        labels = [typ, f'ENV:{config.env}']
        items = title.split('/', 1)
        if len(items) == 2:
            labels.append(items[1])
        else:
            labels.append(title)
        return labels


def main(token, params, request, logger):
    config.update_ansible_config()
    automation = BasicTaskAutomation(token, params, request, logger)
    automation.handle()
