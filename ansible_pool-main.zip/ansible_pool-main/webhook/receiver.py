import json
import logging
import sys
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser
from http.server import BaseHTTPRequestHandler
from http.server import ThreadingHTTPServer
from importlib import import_module
from types import FunctionType, ModuleType
from typing import Optional

module: Optional[ModuleType] = None
logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s',
                    level=logging.INFO,
                    stream=sys.stdout)
logger = logging.getLogger('AUTOMATION-WEBHOOK')


class RequestHandler(BaseHTTPRequestHandler):

    def process_from_module(self, gitlab_token_header, json_params):
        try:
            main_fn: FunctionType = getattr(module, 'main')
        except AttributeError:
            logger.error("Module is invalid or it does not have 'main' function")
            self.send_response(500, 'AttributeError')
            return

        main_fn(gitlab_token_header, json_params, self, logger)

    def do_POST(self):
        logger.info("Hook received")

        content_type = self.headers['Content-Type']
        content_length = int(self.headers['Content-Length'])
        gitlab_token = self.headers.get('X-Gitlab-Token', None)

        payload = self.rfile.read(content_length)
        if content_type == 'application/json' and payload:
            params = json.loads(payload.decode('utf-8'))
        else:
            return self.send_response(200, 'OK')

        self.process_from_module(gitlab_token, params)
        self.end_headers()


def get_parser():
    parser = ArgumentParser(description=__doc__,
                            formatter_class=ArgumentDefaultsHelpFormatter)
    parser.add_argument('--addr', dest='addr', default='0.0.0.0')
    parser.add_argument('--port', dest='port')
    parser.add_argument('-m', '--module', dest='module', help='path to a python module to run')
    return parser


def main():
    global module

    parser = get_parser()
    args = parser.parse_args()
    addr = args.addr
    port = int(args.port)
    module = import_module(args.module)

    httpd = ThreadingHTTPServer((addr, port), RequestHandler)
    logging.info(f'Hook Receiver is listening on {addr}:{port} - {args.module}')
    httpd.serve_forever()


if __name__ == '__main__':
    main()
