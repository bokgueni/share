import datetime
import hashlib
import logging
import os
import subprocess
import time
from concurrent.futures import Future, ProcessPoolExecutor
from typing import Any, Dict, Iterable, Optional

import pytz
import yaml
from croniter import croniter
from yaml.scanner import ScannerError

from config import config
from utils.common import DT_FMT, fmt_dt
from utils.env import get_fabfile_env, get_playbook_env
from utils.git import pull

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(f'TaskScheduler-{os.getpid()}')


def get_task_id(typ, task_dir):
    return hashlib.sha256(f'{typ}-{task_dir}'.encode()).hexdigest()


def update_repository():
    p = pull()
    if (p.stdout is not None and 'Already up to date' in p.stdout.decode()) or p.returncode != 0:
        return
    config.update_ansible_config()
    os.chmod(config.DEFAULT_SSH_KEY_PATH, 0o400)


class PeriodicTask:
    REQUIRED_KEYS = {'enable', 'crontab', 'start', 'end', 'timezone'}

    def __init__(self, config_path, task_config):
        self.type = 'ansible' if 'ansible' in config_path else 'fabric'
        self.task_dir = os.path.dirname(config_path)
        self.id = get_task_id(self.type, self.task_dir)
        self.config = task_config
        self._task: Optional[Future] = None
        self._tick = None
        self._next_tick = None
        self._task_start_time = None

    def __repr__(self):
        return '<%s-%s:%s>' % (self.__class__.__name__, self.type, os.path.basename(self.task_dir))

    @property
    def now(self):
        return datetime.datetime.now(self.config['timezone'])

    @property
    def tick(self):
        return self._tick

    @property
    def delta(self) -> datetime.timedelta:
        init = self._tick is None
        curr_tick = self.crontab.get_next() if init else self._tick
        next_tick = self.crontab.get_next()
        delta = next_tick - curr_tick
        self.crontab.get_prev()
        if init:
            self.crontab.get_prev()
        return delta

    @property
    def crontab(self) -> croniter:
        return self.config['crontab']

    @property
    def enabled(self):
        now = self.now
        enabled = self.config['enable']
        if self.config['start'] is not None:
            enabled &= (self.config['start'] <= now)
        if self.config['end'] is not None:
            enabled &= (self.config['end'] >= now)
        return enabled

    @property
    def runnable(self):
        return self._tick is not None and self._tick <= self.now < self._next_tick

    @property
    def running(self):
        return self._task is not None and self._task.running()

    @property
    def idle(self):
        return self._task is not None and self._task.done() and self.now <= self._next_tick

    @property
    def expired(self):
        return self._next_tick is not None and self.now >= self._next_tick and self.running

    @classmethod
    def from_config(cls, config_path):
        with open(config_path, 'r') as f:
            try:
                task_config = yaml.load(f, yaml.SafeLoader)
            except ScannerError:
                logger.warning(f'Failed to parse config.yml: {config_path}')
                return None

        for k in cls.REQUIRED_KEYS:
            if k in task_config:
                continue

            logger.warning(f'`{k}` is not set in {config_path}')
            return None
        return cls(config_path, cls.normalize_config(task_config))

    @staticmethod
    def normalize_config(cfg):
        if not croniter.is_valid(cfg['crontab']):
            raise ValueError(f"{cfg['crontab']} is not valid crontab format")

        cfg['crontab'] = croniter(cfg['crontab'], ret_type=datetime.datetime)

        if cfg['timezone'] is not None:
            tz = pytz.timezone(cfg['timezone'])
        else:
            tz = pytz.timezone(config.DEFAULT_TIMEZONE)
        cfg['timezone'] = tz

        if cfg['start'] is not None:
            cfg['start'] = tz.localize(cfg['start'])
            now = datetime.datetime.now(tz)
            if cfg['start'] > now:
                cfg['crontab'].set_current(cfg['start'], force=True)
            else:
                cfg['crontab'].set_current(now, force=True)

        if cfg['end'] is not None:
            cfg['end'] = tz.localize(cfg['end'])

        return cfg

    @staticmethod
    def run_operation(_id, typ, task_dir, timeout, **kwargs):
        labels = ['periodic', os.path.basename(task_dir)]
        if typ == 'ansible':
            labels.append('ansible')
            labels = ','.join(labels)
            env = get_playbook_env()
            args = [
                'ansible-playbook',
                os.path.join(task_dir, 'playbook.yml'),
                '-e', f'ara_playbook_labels={labels}',
            ]
        elif typ == 'fabric':
            labels.append('fabric')
            env = get_fabfile_env()
            env.update(LABELS=','.join(labels))
            args = ['fab', 'deploy']
        else:
            raise ValueError(f'Invalid operation type: {typ}')

        kwargs.setdefault('stdout', subprocess.DEVNULL)
        kwargs.setdefault('stderr', subprocess.PIPE)

        p = None
        error = None
        rc = 1
        try:
            p = subprocess.run(args, env=env, cwd=task_dir, timeout=timeout, **kwargs)
            rc = p.returncode
        except subprocess.TimeoutExpired as e:
            error = e
        except subprocess.SubprocessError as e:
            error = e
        except Exception as e:
            error = e

        result = dict(id=_id, rc=rc)
        if error is not None:
            result.update(error=error)
        if p is not None and p.stderr is not None:
            result.update(stderr=p.stderr)
        return result

    def start(self, pool: ProcessPoolExecutor):
        timeout = self.delta.total_seconds()
        self._task_start_time = time.time()
        self._task = pool.submit(self.run_operation, self.id, self.type, self.task_dir, timeout)
        self._task.add_done_callback(self.callback)
        logger.info(f"Task has started: {self}")
        return self._task

    def stop(self):
        if self._task is not None:
            self._task.cancel()
            logger.info(f"Task has cancelled: {self}")

    def callback(self, future: Future):  # noqa
        result = future.result()
        elapsed_time = time.time() - self._task_start_time
        logger.info(f'Task has finished: elapsed time={elapsed_time:.2f}s result={result!r}')
        self._tick = None

    def update_tick(self):
        if self._tick is not None:
            return

        if self._next_tick is not None:
            self._tick = self._next_tick
        else:
            self._tick = self.crontab.get_next()
        self._next_tick = self.crontab.get_next()

        logger.info(f"Task has scheduled at {fmt_dt(self._tick, DT_FMT)}: {self}")

    def update_config(self, cfg: dict[str, Any]):
        self.config.update(cfg)


class TaskScheduler:

    def __init__(self, include_templates=False):
        self.include_templates = include_templates
        self._tasks: Dict[str, PeriodicTask] = {}
        self._task_pool = ProcessPoolExecutor()

    @property
    def tasks(self) -> Iterable[PeriodicTask]:
        return self._tasks.values()

    def register(self, task: Optional[PeriodicTask]):
        if task is None:
            return

        if task.id in self._tasks:
            self._tasks[task.id].update_config(task.config)
        elif task.enabled:
            logger.info(f'New task has registered: {task}')
            self._tasks[task.id] = task

    def load_tasks(self):
        operation_dir = config.PROJECT_ROOT / 'operation'
        for root, dirs, files in os.walk(operation_dir):
            if not self.include_templates and '.templates' in root:
                continue

            if 'config.yml' not in files:
                continue

            config_path = os.path.join(root, 'config.yml')
            pt = PeriodicTask.from_config(config_path)
            self.register(pt)

    def schedule(self):
        for task in self.tasks:
            if task.expired:
                task.stop()
            elif task.running or task.idle:
                continue

            task.update_tick()

    def launch_tasks(self):
        for task in self.tasks:
            if task.running or not task.runnable:
                continue
            task.start(pool=self._task_pool)

    def clean_tasks(self):
        disabled_task_ids = []
        for task in self.tasks:
            if task.enabled:
                continue
            elif task.running:
                task.stop()

            disabled_task_ids.append(task.id)

        for tid in disabled_task_ids:
            task = self._tasks[tid]
            logger.info(f'Disable task: {task}')
            del self._tasks[tid]

    def start(self, *, update_repo=True):
        config.update_ansible_config()

        while True:
            if update_repo:
                self.load_tasks()

            self.schedule()
            self.launch_tasks()
            time.sleep(5)

            if update_repo:
                update_repository()

            self.clean_tasks()

    def shutdown(self):
        self._task_pool.shutdown(wait=False, cancel_futures=True)


def run_all(include_templates=False):
    scheduler = TaskScheduler(include_templates=include_templates)
    try:
        scheduler.start(update_repo=True)
    except Exception as e:  # noqa
        logger.info(f'! Shutdown: {str(e)}')
        scheduler.shutdown()


def run_single(task_dir):
    config_path = os.path.join(task_dir, 'config.yml')
    if not os.path.exists(config_path):
        logger.warning(f'{config_path} does not exist.')

    scheduler = TaskScheduler()
    pt = PeriodicTask.from_config(config_path)

    scheduler.register(pt)
    scheduler.start(update_repo=False)


if __name__ == '__main__':
    run_all()
