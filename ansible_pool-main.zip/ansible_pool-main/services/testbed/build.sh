#!/usr/bin/env bash

docker build -t imubuntu -f Ubuntu.Dockerfile . &
docker build -t imcentos -f CentOS.Dockerfile . &
docker build -t imfedora -f Fedora.Dockerfile . &
