#!/usr/bin/env bash

MINIO_ROOT_USER=ls22lab
MINIO_ROOT_PASSWORD=ls22lab!

ROOT_DIR="$(realpath "$(dirname "$0")")"
DATA_DIR="$ROOT_DIR/data"
MINIO_BIN="$ROOT_DIR/minio"
MC_BIN="$ROOT_DIR/mc"

if [ ! -d "$DATA_DIR" ]; then
  mkdir "$DATA_DIR"
fi

if [ ! -f "$MINIO_BIN" ]; then
  echo "Download minio"
  wget https://dl.min.io/server/minio/release/linux-amd64/minio
  chmod +x "$MINIO_BIN"
fi

if [ ! -f "$MC_BIN" ]; then
  echo "Download mc"
  wget https://dl.min.io/client/mc/release/linux-amd64/mc
  chmod +x "$MC_BIN"
fi

$MINIO_BIN server "$DATA_DIR" --address 10.11.59.2:9000 --console-address ":9001" &
disown

echo "Wait for minio service"
sleep 3

$MC_BIN alias set minio http://10.11.59.2:9000 ${MINIO_ROOT_USER} ${MINIO_ROOT_PASSWORD}
$MC_BIN mb minio/operation
$MC_BIN mb minio/public
$MC_BIN policy set public minio/operation
$MC_BIN policy set public minio/public
