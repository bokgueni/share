import shutil
import subprocess

from config import config
from utils.env import get_ara_env, get_minio_env, get_periodic_runner_env, get_webhook_env


def service_ara(command, *, foreground=False, rebuild=False):
    env = get_ara_env(rebuild=rebuild)
    cwd = config.SERVICE_DIR / 'ansible-ara'
    if command == 'start':
        args = ['docker-compose', 'up', '--build']
        if not foreground:
            args.append('-d')
    else:
        args = ['docker-compose', 'down']
    subprocess.run(args, env=env, cwd=cwd.as_posix())


def service_webhook(command, *, foreground=False, rebuild=False):
    local_config_path = config.PROJECT_ROOT / 'config' / 'local.py'
    webhook_dir = config.SERVICE_DIR / 'webhook'
    shutil.copyfile(local_config_path, webhook_dir / 'operation' / 'local.py')
    shutil.copyfile(local_config_path, webhook_dir / 'notification' / 'local.py')

    env = get_webhook_env(rebuild=rebuild)
    cwd = config.SERVICE_DIR / 'webhook'
    if command == 'start':
        args = ['docker-compose', 'up', '--build']
        if not foreground:
            args.append('-d')
    else:
        args = ['docker-compose', 'down']
    subprocess.run(args, env=env, cwd=cwd.as_posix())


def service_periodic_runner(command, *, foreground=False, rebuild=False):
    shutil.copyfile(
        config.PROJECT_ROOT / 'config' / 'local.py',
        config.SERVICE_DIR / 'periodic-runner' / 'local.py',
    )

    env = get_periodic_runner_env(rebuild=rebuild)
    cwd = config.SERVICE_DIR / 'periodic-runner'
    if command == 'start':
        args = ['docker-compose', 'up', '--build']
        if not foreground:
            args.append('-d')
    else:
        args = ['docker-compose', 'down']
    subprocess.run(args, env=env, cwd=cwd.as_posix())


def service_minio(command, *, foreground=False, rebuild=False):
    env = get_minio_env(rebuild=rebuild)
    cwd = config.SERVICE_DIR / 'minio'
    if command == 'start':
        args = ['docker-compose', 'up']
        if not foreground:
            args.append('-d')
    else:
        args = ['docker-compose', 'down']
    subprocess.run(args, env=env, cwd=cwd.as_posix())
