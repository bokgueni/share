if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    New-Item -ItemType File -Name "not_Admin.txt"
    exit
}

New-Item -ItemType File -Name "Admin.txt"
