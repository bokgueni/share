$keyPath = "HKLM:\SOFTWARE\OpenSSH"
$valueName = "defaultshell"
$newValue = "C:\windows\system32\cmd.exe"


# 레지스트리 값 설정
New-ItemProperty -Path $keyPath -Name $valueName -Value $newValue -PropertyType String -Force | Out-Null