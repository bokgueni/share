$ErrorActionPreference = "SilentlyContinue"

$hostname = $env:COMPUTERNAME.ToLower()

& .\autorunsc64.exe -accepteula -nobanner -a * -ct -h -o autoruns.csv *
& .\mc.exe alias set LS24 http://220.72.26.110:9000/ UGFpDDLJmVBdkzziN7YR l30ozH72EaRb5jwgfrY6hDI3g50iE1jma4i7wXTA
& .\mc.exe cp autoruns.csv "LS24/ls24-beg-data/backup/$hostname/$($hostname)_autoruns.csv" 

$zipFilePath = "$($hostname)_run_Unsigned.zip"

$registryKeys = @(
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnceEx"
)

$unsignedFiles = @()

foreach ($key in $registryKeys) {
    try {
        $registryItems = Get-ItemProperty -Path $key
        $names = $registryItems | Get-Member -MemberType NoteProperty | Where-Object { $_.Name -notin @("PSPROVIDER", "PSDRIVE", "PSCHILDNAME", "PSPARENTPATH", "PSPATH") } | ForEach-Object { $_.Name }
        foreach ($name in $names) {
            $value = $registryItems | Select-Object -ExpandProperty $name
            if ($value -match '(?<=\").*?(?=\")') {
                $value = $matches[0]
            }
            Write-Host "Checking file :" $value
            if ((Test-Path $value) -and !(& .\sigcheck64.exe -nobanner -accepteula -e -ct $value | Select-String -Pattern "Signed" -Quiet)) {
            	Write-Host "Unsignd file :" $value
            	$unsignedFiles += $value
            	}
        	}
    }
    catch {
        Write-Host "Error accessing registry key: $_"
    }
}

if ($unsignedFiles.Count -gt 0) {
    Compress-Archive -Path $unsignedFiles -DestinationPath $zipFilePath -Force
    Write-Host "Unsigned files zipped"
    & .\mc.exe cp $zipFilePath "LS24/ls24-beg-data/backup/$hostname/$zipFilePath" 

} else {
    Write-Host "Unsigned files does not exist"
}
