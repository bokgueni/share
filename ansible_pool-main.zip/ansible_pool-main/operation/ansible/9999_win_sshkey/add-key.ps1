Add-Content -Path C:\Users\Administrator\.ssh\authorized_keys -Value "`r`nssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIF//VTfV6UEdk/SmU+aG7koX0FSMNLXC20X6zpbwe0Eq"
