from utils.fabric_wrapper import task


@task('win10_113', gather_facts=True)
def deploy(c):
    r = c.run('netstat -ano | findstr LISTEN')

    curr_listen_addrs = set()
    for line in r.stdout.splitlines():
        proto, bind_addr, inbound_addr, status, pid = line.split()
        if bind_addr.startswith('127.0.0.1'):
            continue
        curr_listen_addrs.add(f'[proto={proto}|addr={bind_addr}|pid={pid}]')

    opened_listen_addrs = {}
    closed_listen_addrs = {}
    saved_listen_addrs = c.load_cache('listen_addrs')
    if saved_listen_addrs is not None:
        opened_listen_addrs = curr_listen_addrs.difference(saved_listen_addrs)
        closed_listen_addrs = saved_listen_addrs.difference(curr_listen_addrs)

    if opened_listen_addrs:
        c.label('compromised')
        c.log(f"Found new opened listening addresses: {', '.join(opened_listen_addrs)}")

    if closed_listen_addrs:
        c.label('compromised')
        c.log(f"Found new closed listening addresses: {', '.join(closed_listen_addrs)}")

    c.update_cache('listen_addrs', curr_listen_addrs)
