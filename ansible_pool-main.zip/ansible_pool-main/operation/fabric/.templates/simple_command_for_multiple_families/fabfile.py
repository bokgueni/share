from utils.fabric_wrapper import LoggableConnection, task


def host_filter(host):
    return host['inventory_hostname'] == 'win10_113'


@task('sample', gather_facts=True)
def deploy(conn: LoggableConnection):
    ctx = conn.ctx
    facts = ctx.facts  # facts contains environment variables for target node
    if ctx.is_windows:
        home_directory = facts.USERPROFILE
    elif ctx.is_linux:
        home_directory = facts.HOME
    else:
        home_directory = 'unknown'

    print(f"Host={conn.host}, User={conn.user}, HOME=${home_directory}")
