from utils.fabric_wrapper import task


@task('win10_113', gather_facts=True)
def deploy(c):
    facts = c.ctx.facts
    remote_path = f'{facts.USERPROFILE}\\Downloads\\sample.txt'
    remote_dir = f'{facts.USERPROFILE}\\Downloads'

    c.put('.templates/static/sample.txt', remote_path, via='minio')
    c.put('.templates/static', remote_dir, via='minio', directory_mode=True)

    c.get(remote_path, '.templates/fabric-sample.txt', via='minio')
    c.get(f'{remote_dir}\\static', '.templates/fabric-sampled', via='minio', directory_mode=True)
    c.get(f'{remote_dir}\\static', '.templates/fabric-sampled-flat', via='minio',
          directory_mode=True, flat=True)
