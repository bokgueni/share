from utils.fabric_wrapper import task


@task('win10_113')
def deploy(c):
    # Some Windows OS returns non-zero code for this command, so set `warn` to True
    r = c.run('net user', hide=True, warn=True)

    saved_users = c.load_cache('users')
    users = set(' '.join(r.stdout.strip().split('\r\n')[3:-1]).split())
    new_users = {}
    if saved_users is not None:
        new_users = users.difference(saved_users)

    if saved_users is not None and new_users:
        # TODO: Support labeling such as 'critical' and 'compromised'
        print('Found new user:', *new_users)
    c.update_cache('users', users)
