from utils.fabric_wrapper import LoggableConnection, task


def host_filter(host):
    return host['inventory_hostname'] == 'win10_113'


# git commit -m "op-fabric-00000/fabric-test-15"
@task('sample', host_filter=host_filter)
def deploy(conn: LoggableConnection):
    conn.run("hostname", hide=True)
    conn.run("type C:\\Windows\\win.ini", hide=True)
    conn.run("net user", warn=True, hide=True)
