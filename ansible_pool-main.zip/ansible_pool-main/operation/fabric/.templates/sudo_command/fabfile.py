from utils.fabric_wrapper import task


@task('junsang_ubuntu_136')
def deploy(conn):
    r = conn.sudo('cat /etc/shadow', hide=True)
    if r.stdout:
        print(r.stdout)
