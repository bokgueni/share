import platform
import subprocess

from minio import Minio

from config import config


def escape_path(path):
    path = path.replace('\\', '/')
    if ':' in path and path.split('/')[0].endswith(':'):
        path = f'/{path}'
    return path


def create_minio_client():
    return Minio(
        f'{config.MINIO_SERVER_HOST}:{config.MINIO_SERVER_PORT}',
        access_key=config.MINIO_ROOT_USER,
        secret_key=config.MINIO_ROOT_PASSWORD,
        secure=False,
    )


def update_minio_bucket(client: Minio, bucket_name=config.MINIO_DEFAULT_BUCKET_NAME):
    found = client.bucket_exists(bucket_name)
    if not found:
        client.make_bucket(bucket_name)


def scp_copy(src, dest, key_path, host, port, user, directory_mode=False, fetch=False, dry=False):
    args = ['scp']
    if directory_mode:
        args.append('-r')
    if len(user.split('\\')) > 1 and platform.system() != 'Windows':
        user = user.replace('\\', '\\\\')

    args.extend([
        '-i', key_path,
        '-P', str(port),
        '-o', '"StrictHostKeyChecking=no"',
        '-o', '"UserKnownHostsFile=/dev/null"',
        '-o', 'LogLevel=ERROR',
    ])
    if fetch:
        src = f'{user}@{host}:"{escape_path(src)}"'
    else:
        dest = f'{user}@{host}:"{escape_path(dest)}"'

    args.extend([src, dest])
    cmd = ' '.join(args)

    if dry:
        return cmd

    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, shell=True)
    except subprocess.SubprocessError as e:
        return e
