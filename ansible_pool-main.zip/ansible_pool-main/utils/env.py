import os
import subprocess
import time

from config import config
from utils.git import get_current_commit_sha


def _rng(rebuild):
    return '-' if not rebuild else str(int(time.time()))


def get_ara_env(*, rebuild=False):
    env = os.environ.copy()
    env.update(
        ARA_API_PORT=str(config.ARA_API_PORT),
        ARA_TIME_ZONE=config.ARA_TIME_ZONE,
        BUILD=_rng(rebuild),
    )
    return env


def get_webhook_env(*, rebuild=False):
    commit = get_current_commit_sha()
    env = os.environ.copy()
    env.update(
        ENV=config.env,
        HOST=config.host,
        COMMIT_SHA=commit,
        REDIS_PORT=str(config.REDIS_PORT),
        ARA_API_SERVER=config.ansible_ara_endpoint,
        GITLAB_HOST=config.GITLAB_HOST,
        GITLAB_PROJECT_URL=config.gitlab_project_url,
        GITLAB_ACCESS_TOKEN=config.GITLAB_ACCESS_TOKEN,
        GITLAB_ADMIN_READONLY_TOKEN=config.GITLAB_ADMIN_READONLY_TOKEN,
        AUTOMATION_WEBHOOK_PORT=str(config.AUTOMATION_WEBHOOK_PORT),
        NOTIFICATION_WEBHOOK_PORT=str(config.NOTIFICATION_WEBHOOK_PORT),
        ISSUE_MAN_SLACK_TOKEN=config.ISSUE_MAN_SLACK_TOKEN,
        BUILD=_rng(rebuild),
    )
    return env


def get_periodic_runner_env(*, rebuild=False):
    return get_webhook_env(rebuild=rebuild)


def get_minio_env(*, rebuild=False):
    env = os.environ.copy()
    env.update(
        MINIO_SERVER_URL=config.minio_endpoint,
        MINIO_SERVER_PORT=str(config.MINIO_SERVER_PORT),
        MINIO_CONSOLE_PORT=str(config.MINIO_CONSOLE_PORT),
        MINIO_ROOT_USER=config.MINIO_ROOT_USER,
        MINIO_ROOT_PASSWORD=config.MINIO_ROOT_PASSWORD,
        BUILD=_rng(rebuild),
    )
    return env


def get_playbook_env():
    env = os.environ.copy()
    env.update(
        ENV=config.env,
        ANSIBLE_CONFIG=config.ANSIBLE_CONFIG_PATH.as_posix(),
        ANSIBLE_CALLBACK_PLUGINS=(config.PROJECT_ROOT / 'plugins' / 'callback').as_posix(),
        ARA_API_CLIENT='http',
        ARA_API_SERVER=config.ansible_ara_endpoint,
        PYTHONPATH=config.PROJECT_ROOT.as_posix(),
    )
    return env


def get_fabfile_env():
    hostname = subprocess.check_output('hostname', shell=True).strip().decode()
    env = os.environ.copy()
    env.update(
        ENV=config.env,
        ANSIBLE_CONFIG=config.ANSIBLE_CONFIG_PATH.as_posix(),
        ARA_API_CLIENT='http',
        ARA_API_SERVER=config.ansible_ara_endpoint,
        PYTHONPATH=config.PROJECT_ROOT.as_posix(),
        COMMIT_TITLE=f'{hostname}',
    )
    return env
