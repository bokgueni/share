import configparser
import os
import shutil
import tempfile
import types
from typing import List, Optional, Union

import yaml
from ansible.inventory.host import Host
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader

from config import config

SSH_BASE_CONFIG = '''
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile=/dev/null
    IdentityFile {key_path}
'''.strip()
SSH_CONFIG_TEMPLATE = '''
Host {host}
    HostName {host}
    Port {port}
    User {user}
'''.strip()
PROXY_COMMAND_TEMPLATE = "ProxyJump {host}"


class Inventory:

    def __init__(self, pattern='all', host_fileter=None):
        self.runtime_ssh_config_path = None
        self.inventory_manager = InventoryManager(loader=DataLoader(), sources=self._load_sources())
        self.hosts = self.inventory_manager.get_hosts(pattern)
        self.targets = self._serialize_hosts(self.hosts)
        self._targets_by_hostname = {}
        for target in self.targets:
            self._targets_by_hostname[target['inventory_hostname']] = target
        if host_fileter is not None:
            self.apply_filter(host_fileter)

    def __del__(self):
        if (self.runtime_ssh_config_path is not None
            and os.path.exists(self.runtime_ssh_config_path)):
            os.remove(self.runtime_ssh_config_path)

    @staticmethod
    def _load_sources():
        config.update_ansible_config()
        parser = configparser.ConfigParser()
        parser.read(config.ANSIBLE_CONFIG_PATH.as_posix())
        inventory = parser.get('defaults', 'inventory')
        if not inventory:
            return None
        return inventory.split(',')

    @staticmethod
    def _serialize_hosts(hosts: List[Host]):
        _hosts = []
        for h in hosts:
            data = h.get_vars()
            data['host'] = data['ansible_host']
            data['port'] = data.get('ansible_port', config.DEFAULT_SSH_PORT)
            data['user'] = data.get('ansible_user', config.DEFAULT_SSH_USER)
            data['sudo_pass'] = data.get('ansible_sudo_password') or data.get('ansible_su_password')
            data['timeout'] = data.get('ansible_ssh_timeout', config.DEFAULT_SSH_TIMEOUT)
            _hosts.append(data)
        return _hosts

    def apply_filter(self, flt: types.FunctionType):
        targets = []
        for host in self.targets:
            if flt(host):
                targets.append(host)
        self.targets = targets

    def get_by_hostname(self, hostname):
        return self._targets_by_hostname.get(hostname, None)


def load_inventory(
    *sources: str,
    host_filter: Optional[Union[types.LambdaType, types.FunctionType]] = None
):
    parser = configparser.ConfigParser()
    parser.read(config.ANSIBLE_CONFIG_PATH.as_posix())
    private_key_path = parser.get('defaults', 'private_key_file')

    jump_hosts = set()
    jumps_by_dest = {}
    jump_points_path = config.CONFIG_DIR / 'jump-points.yml'
    with jump_points_path.open('r') as f:
        data = yaml.load(f, yaml.BaseLoader)
    for point in data['points']:
        dest = point.get('dest', None)
        jump = point.get('jump', None)
        if dest is None or jump is None:
            continue
        jump_hosts.add(dest)
        jump_hosts.add(jump)
        jumps_by_dest[dest] = jump

    inventory = Inventory(pattern=','.join(sources), host_fileter=host_filter)
    jump_inventory = Inventory(pattern=','.join(jump_hosts))

    base_config = SSH_BASE_CONFIG.format(key_path=private_key_path)
    configs = [base_config]
    for target in inventory.targets:
        raw_ssh_config = SSH_CONFIG_TEMPLATE.format(
            host=target['host'],
            port=target['port'],
            user=target['user'],
            key_path=private_key_path,
        )
        if target['inventory_hostname'] in jumps_by_dest:
            hostname = target['inventory_hostname']
            jump_host = jumps_by_dest[hostname]
            jump = jump_inventory.get_by_hostname(jump_host)
            raw_ssh_config += (
                '\n    ' + PROXY_COMMAND_TEMPLATE.format(user=jump['user'], host=jump['host'])
            )
        configs.append(raw_ssh_config)

    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write('\n\n'.join(configs))
        f.write('\n')

    inventory.runtime_ssh_config_path = f.name
    return inventory


def create_jump_points_ssh_config():
    jump_points_path = config.CONFIG_DIR / 'jump-points.yml'
    with jump_points_path.open('r') as f:
        data = yaml.load(f, yaml.BaseLoader)
    points = data['points']

    hosts = set()
    for point in points:
        hosts.add(point['dest'])
        hosts.add(point['jump'])

    inventory = load_inventory(*hosts, host_filter=lambda h: h['inventory_hostname'] in hosts)  # noqa
    ssh_config_path = config.CONFIG_DIR / 'ssh.cfg'
    shutil.copyfile(inventory.runtime_ssh_config_path, ssh_config_path)
    del inventory
    return ssh_config_path.as_posix()
