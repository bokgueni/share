import binascii
import os
import subprocess

from config import config


def get_current_commit_sha():
    try:
        return subprocess.check_output(['git', 'rev-parse', 'HEAD'], stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        return binascii.hexlify(os.urandom(8)).decode()


def reset_changes():
    p = subprocess.run(['git', 'checkout', '.'], stderr=subprocess.DEVNULL)
    return p.returncode == 0


def pull():
    return subprocess.run(['git', 'pull'], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)


def get_username():
    try:
        p = subprocess.run(['git', 'config', 'user.name'], stdout=subprocess.PIPE)
        username = p.stdout.decode().strip()
    except:  # noqa
        username = None
    if not username:
        return None
    return username


def get_gitlab_client():
    token = config.GITLAB_ADMIN_READONLY_TOKEN
    if token is None:
        raise ValueError(
            f'GITLAB_ADMIN_READONLY_TOKEN is not set. '
            f'Create a personal access token in {config.gitlab_endpoint} and add it to secret.py.',
        )

    import gitlab

    url = f'{config.GITLAB_SCHEME}://{config.GITLAB_HOST}'
    if config.GITLAB_PORT not in [80, 443]:
        url += f':{config.GITLAB_PORT}'
    return gitlab.Gitlab(url=url, private_token=token)
