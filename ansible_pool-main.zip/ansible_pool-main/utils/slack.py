import io
import pathlib
import uuid

import requests
from minio.commonconfig import Tags
from slack_sdk import WebClient
from traceback_with_variables import iter_exc_lines

from config import config
from utils.file import create_minio_client

WEBHOOK_ERROR_TEMPLATE = """Hey <@{username}>
Error: <#EB0014|{error}>"""


def get_slack_client():
    token = config.ISSUE_MAN_SLACK_TOKEN
    if token is None:
        raise ValueError(
            "ISSUE_MAN_SLACK_TOKEN is not set. "
            "Create a bot in Slack service and add it to secret.py."
        )
    return WebClient(token)


def send_slack_message(data):
    requests.post(
        config.SLACK_WEBHOOK_URL,
        headers={'Content-Type': 'application/json'},
        json=data,
    )


def send_webhook_debug_message(commit, typ, e: Exception):
    bucket = config.MINIO_DEBUG_BUCKET_NAME
    use_fallback = False
    gitlab_username = commit['user_name']
    slack_username = config.GITLAB_SLACK_USERS_MAP.get(gitlab_username)
    if slack_username is None:
        use_fallback = True
        slack_username = config.AUTOMATION_SLACK_ADMIN

    client = create_minio_client()
    found = client.bucket_exists(bucket)
    if not found:
        client.make_bucket(bucket)

    data = '\n'.join(iter_exc_lines(e))
    stream = io.BytesIO()
    stream.write(data.encode())
    stream.seek(0)

    uid = str(uuid.uuid4())
    object_name = (pathlib.Path(uid) / 'debug.txt').as_posix()
    tags = Tags(for_object=True)
    tags['User'] = gitlab_username
    tags['Type'] = typ
    client.put_object(bucket, object_name, stream, len(data),
                      content_type='text/plain', tags=tags)
    url = client.get_presigned_url('GET', config.MINIO_DEBUG_BUCKET_NAME, object_name)
    message = dict(blocks=[
        dict(type='section', text=dict(type='plain_text', text=f"ERROR: {commit['title']}")),
        dict(type='section',
             text=dict(
                 type='mrkdwn',
                 text=f"Hey <@{slack_username}>, check this error: <{url}|{str(e)}>")),
    ])

    if use_fallback:
        message['blocks'].append(dict(
            type='section',
            text=dict(
                type='mrkdown',
                text=f'_It is originally created by {gitlab_username}_'
            )))

    send_slack_message(message)
