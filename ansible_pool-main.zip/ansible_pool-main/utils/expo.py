import argparse
import os.path
from typing import Optional

import requests

# Accessing to game network using domain name with requests module is too slow
# BASE = 'https://expo.berylia.org'
BASE = 'https://100.100.100.20'
HOST = 'expo.berylia.org'
base_dir = None
access_token = None
access_token_cache_path: Optional[str] = None


def init():
    global base_dir
    global access_token_cache_path

    home_dir = os.path.expanduser('~')
    expo_dir = os.path.join(home_dir, '.expo')
    if not os.path.exists(expo_dir):
        os.mkdir(expo_dir)

    assert os.path.isdir(expo_dir)

    access_token_cache_path = os.path.join(expo_dir, 'access_token')


def acquire_access_token(username, password, renew=False):
    global access_token

    if (access_token_cache_path is not None
        and os.path.isfile(access_token_cache_path)
        and not renew):
        print(f'Load access token from {access_token_cache_path}')
        with open(access_token_cache_path, 'r') as f:
            access_token = f.read()
        return

    res = requests.post(
        'https://login.cr14.net/auth/realms/LS22-EXPO/protocol/openid-connect/token',
        headers={
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        data=dict(
            username=username,
            password=password,
            grant_type='password',
            client_id='ls22-expo',
        ),
    )
    if res.status_code == 200:
        access_token = res.json()['access_token']
        with open(access_token_cache_path, 'w') as f:
            f.write(access_token)


def get_credentials(search):
    data = dict(
        variables=dict(
            limit=1000,
            filters=dict(readonly=[False]),
            search=search,
            sort=[dict(by='realm', order='desc')],
        ),
        query="""query Credentials($limit: Int, $filters: CredentialQueryFiltersInput, $sort: [QuerySortArgsInput!], $search: String) {
              credentials(limit: $limit, filters: $filters, sort: $sort, search: $search) {
                _id
                realm
                readonly
                email
                department
                display_name
                username
                password
                password_original
                domain
                description
                team
                has_services
                services {
                  uri
                  description
                  systems
                  uris
                }
                updated_time
              }
            }"""
    )


def get_systems():
    data = dict(
        variables=dict(
            limit=200,
            sort=[dict(by='expo_id', order='asc')],
            filters=[],
        ),
        query="""query Systems($limit: Int, $sort: [QuerySortArgsInput!], $search: String, $filters: SystemQueryFiltersInput) {
              systems(limit: $limit, sort: $sort, search: $search, filters: $filters) {
                _id
                expo_id
                hostname
                hostname_common
                description
                has_services
                team
                team_name
                domain
                zones
                os
                ansible_role
                network_interfaces {
                  network_id
                  cloud_id
                  domain
                  fqdn
                  egress
                  connection
                  addresses {
                    mode
                    connection
                    address
                    address_without_subnet
                    subnet
                    gateway
                  }
                }
                availability_status
                availability_change_time
                service_checks {
                  availability_id
                  availability_status
                  availability_change_time
                  availability_check_output
                  service_name
                  source_network_id
                  special
                  protocol
                  ip
                  port
                }
              }""",
    )
    r = requests.get(
        f'{BASE}/api',
        verify=False,
        headers={
            'Host': HOST,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': f'Bearer {access_token}',
        },
        json=data,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', dest='username', required=True)
    parser.add_argument('-p', dest='password', required=True)
    args = parser.parse_args()

    acquire_access_token(args.username, args.password)


init()
main()
print(access_token)
# get_systems()
