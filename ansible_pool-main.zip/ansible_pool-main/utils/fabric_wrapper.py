import collections
import datetime
import functools
import hashlib
import os
import shutil
import subprocess
import tempfile
import traceback
import uuid
from typing import Any, Optional

import fabric
import invoke
import paramiko
from ara.clients.http import AraHttpClient
from invoke import Responder

from config import config
from plugins.action.minio_copy import get_download_info, minio_copy_to_local
from plugins.action.minio_fetch import minio_fetch_to_minio
from utils import cache
from utils.cache import WEBHOOK_DB
from utils.common import dictize, fmt_dt, get_parent_frame, tz_now
from utils.file import escape_path, scp_copy
from utils.git import get_username
from utils.inventory import load_inventory

client = AraHttpClient(endpoint=config.ansible_ara_endpoint, timeout=5)
hostname = subprocess.check_output('hostname').decode().strip()
username = get_username()
DEBUG = bool(os.getenv('DEBUG'))
SHELL = subprocess.check_output('echo $0', shell=True).decode().strip()


def loggable(func):
    @functools.wraps(func)
    def wrapper(c: 'LoggableConnection', *args, **kwargs):
        cmd_args = [func.__name__.upper()]
        cmd_args.extend(map(str, args))
        for k, v in kwargs.items():
            cmd_args.append(f'{k}={v}')
        cmd = ' '.join(cmd_args)

        tr = AraTaskResult(c.host, c.port, func.__name__, cmd)
        try:
            result: Optional[fabric.Result] = func(c, *args, **kwargs)
        except (invoke.UnexpectedExit, invoke.Failure, invoke.ThreadException) as e:
            result = None
            tr.content = dict(error=str(e), trace=traceback.format_exc())

        if result is not None:
            tr.content = dict(
                ok=result.return_code == 0 or kwargs.get('warn', False),
                command=tr.command,
                rc=result.return_code,
                stdout=result.stdout,
                stderr=result.stderr,
            )

        if tr.content.get('ok') or kwargs.get('ignore_errors'):
            tr.status = 'ok'
        else:
            tr.status = 'failed'

        tr.update_frame()
        tr.ended = tz_now()
        c.task_results.append(tr)
        return result

    return wrapper


class AraHost:
    __slots__ = ('id', 'name', 'host', 'port', 'changed', 'failed', 'ok', 'unreachable',)

    def __init__(self, name, host, port):
        self.id = None
        self.name = name
        self.host = host
        self.port = port
        self.changed = 0
        self.failed = 0
        self.ok = 0
        self.unreachable = 0

    @property
    def key(self):
        return f'{self.host}:{self.port}'

    @classmethod
    def from_inventory_target(cls, target):
        return cls(target['inventory_hostname'], target['host'], target['port'])


class AraTask:
    __slots__ = ('action', 'lineno', 'status',)

    def __init__(self, action, lineno, status):
        self.action = action
        self.lineno = lineno
        self.status = status

    def __str__(self):
        return f'<{self.__class__.__name__}:{self.action}/{self.lineno}L>'

    def __repr__(self):
        return self.__str__()

    @classmethod
    def from_task_result(cls, tr: 'AraTaskResult'):
        return cls(tr.action, tr.lineno, 'completed')

    def to_dict(self):
        return dict(
            action=self.action,
            lineno=self.lineno,
            status=self.status,
            handler=False,
        )


class AraTaskResult:
    __slots__ = (
        'host', 'port', 'action', 'command', 'started', 'ended', 'status', 'content', 'filename',
        'lineno',
    )

    def __init__(self, host, port, action, command):
        self.host = host
        self.port = port
        self.action = action
        self.command = command
        self.started = tz_now()
        self.ended = None
        self.status = 'unknown'
        self.content = None
        self.filename = None
        self.lineno = None

    def __str__(self):
        return f'<{self.__class__.__name__}({self.host}:{self.port}):{self.action}/{self.lineno}L>'

    def __repr__(self):
        return self.__str__()

    @property
    def host_key(self):
        return f'{self.host}:{self.port}'

    @classmethod
    def create_empty_result_of_task(cls, t: AraTask):
        tr = cls(None, None, t.action, None)
        tr.content = {'description': "This task did not work properly."}
        tr.status = 'unreachable'
        tr.ended = fmt_dt(tz_now(as_str=False) + datetime.timedelta(hours=5, minutes=5, seconds=55))
        return tr

    @classmethod
    def create_unexpected_exception_result(cls, host: AraHost, e):
        tr = cls(host.host, host.port, 'error', '')
        tr.lineno = 1
        tr.ended = fmt_dt(tz_now(as_str=False) + datetime.timedelta(hours=5, minutes=5, seconds=55))
        tr.status = 'failed'
        tr.content = {
            'description': f'Error occurred while executing the task for {host.key}',
            'error': str(e),
            'trace': traceback.format_exc(),
        }
        return tr

    def to_dict(self):
        return dict(
            content=self.content,
            status=self.status,
            delegated_to=[],
            changed=self.status == 'ok',
            started=self.started,
            ended=self.ended,
        )

    def update_result(self, result: fabric.Result, ignore_errors=False):
        self.ended = tz_now()
        if result.ok or ignore_errors:
            self.status = 'ok'
        else:
            self.status = 'failed'
        self.content = {
            'command': self.command,
            'rc': result.return_code,
            'stdout': result.stdout,
            'stderr': result.stderr,
        }
        self.update_frame()

    def update_frame(self):
        frame = get_parent_frame(__file__)
        self.filename = frame.filename
        self.lineno = frame.lineno


class LoggableTask(fabric.Task):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ctx = None

    def __call__(self, *args, **kwargs):
        # Guard against calling tasks with no context.
        if not isinstance(args[0], invoke.Context):
            err = "Task expected a Context as its first arg, got {} instead!"
            raise TypeError(err.format(type(args[0])))
        self.ctx = args[0]
        result = self.body(*args, **kwargs)
        self.times_called += 1
        return result


class LoggableConnection(fabric.Connection):

    def __init__(self, ctx, *args, **kwargs):
        target = kwargs.pop('target')
        kwargs.update(
            host=target['host'],
            port=target['port'],
            connect_timeout=target['timeout'],
        )
        super().__init__(*args, **kwargs)
        self._set(hostname=target['inventory_hostname'])
        self._set(ctx=ctx)
        self._set(logs=[])
        self._set(labels=[])
        self._set(task_results=[])
        self._set(sudo_responder=Responder(
            pattern=r'\[sudo\].*',
            response=f"{target['sudo_pass']}\n",
        ))
        self._set(cache=None)

    def __exit__(self, *exc):
        if self.cache is not None:
            self.cache.close()
            self.cache = None
        self.close()

    def get_cache_client(self):
        if self.cache is None:
            self.cache = cache.create_redis_client(WEBHOOK_DB)
        return self.cache

    def unsafe_run(self, command, **kwargs):
        kwargs.setdefault('hide', True)
        kwargs.setdefault('warn', True)
        # noinspection PyBroadException
        try:
            return super().run(command, **kwargs)
        except Exception:
            return None

    def log(self, text):
        self.logs.append(text)

    def label(self, *names):
        self.labels.extend(names)

    def local(self, command, **kwargs):
        kwargs.update(shell=SHELL)
        return super().local(command, **kwargs)

    @loggable
    def run(self, command, **kwargs):
        kwargs.setdefault('hide', True)
        return super().run(command, **kwargs)

    @loggable
    def sudo(self, command, **kwargs):
        kwargs.update(pty=True, watchers=[self.sudo_responder])
        return super().sudo(command, **kwargs)

    @loggable
    def get(self, remote, dest, via=None, **kwargs):
        warn = kwargs.pop('warn', False)
        temp_dir = tempfile.mkdtemp()
        directory_mode = kwargs.get('directory_mode', False)

        cmd = scp_copy(remote, temp_dir,
                       self.connect_kwargs['key_filename'][0], self.host, self.port, self.user,
                       directory_mode=directory_mode, fetch=True, dry=True)
        result = self.local(cmd, warn=warn)
        remote = escape_path(remote)
        if via == 'minio':
            sources = []
            for root, dirs, files in os.walk(temp_dir):
                sources.extend(map(lambda f: os.path.join(root, f), files))

            has_same_basename = os.path.basename(remote) == os.path.basename(dest)
            if has_same_basename:
                dest = os.path.dirname(dest)
            minio_fetch_to_minio(temp_dir, sources, dest, **kwargs)

        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)

        return result

    @loggable
    def put(self, src, remote, via=None, **kwargs):
        warn = kwargs.pop('warn', False)
        bucket = kwargs.get('bucket', config.MINIO_DEFAULT_BUCKET_NAME)
        directory_mode = kwargs.get('directory_mode', False)

        r = self.unsafe_run(f'curl -X OPTIONS {config.minio_raw_endpoint} --connect-timeout 1')
        wget_usable = r is not None and r.return_code == 0
        if wget_usable:
            info = get_download_info(src, remote, bucket=bucket, directory_mode=directory_mode)
            for data in info:
                cmd = f"curl -L -o {data['dest']} {data['url']}"
                print(cmd)
                self.unsafe_run(cmd)
            return self.local('echo "download using wget"')

        if via == 'minio':
            src = minio_copy_to_local(src=src, **kwargs)

        remote = escape_path(remote)
        cmd = scp_copy(src, remote,
                       self.connect_kwargs['key_filename'][0], self.host, self.port, self.user,
                       directory_mode=directory_mode, dry=True)
        result = self.local(cmd, warn=warn)

        return result

    @staticmethod
    def get_cache_key(k):
        fabfile_path = get_parent_frame(__file__)
        return f'{hashlib.sha1(fabfile_path.filename.encode()).hexdigest()}:{k}'

    def load_cache(self, k, decode=True) -> Optional[Any]:
        return cache.load(WEBHOOK_DB, self.get_cache_key(k),
                          client=self.get_cache_client(), decode=decode)

    def save_cache(self, k, v):
        return cache.save(WEBHOOK_DB, self.get_cache_key(k), v,
                          client=self.get_cache_client())

    def update_cache(self, k, v):
        k = self.get_cache_key(k)
        cache.delete(WEBHOOK_DB, k, client=self.get_cache_client())
        return cache.save(WEBHOOK_DB, k, v, client=self.get_cache_client())

    def delete_cache(self, k):
        cache.delete(WEBHOOK_DB, self.get_cache_key(k), client=self.get_cache_client())


class TaskHelper:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.conn: Optional[LoggableConnection] = None
        self._handlers = {
            'gather_facts': self._gather_facts,
        }

    @property
    def enabled(self):
        return any(self._handlers.get(k) for k in self.kwargs)

    def set_connection(self, connection: LoggableConnection):
        self.conn = connection

    def process(self):
        for k in self.kwargs:
            handler = self._handlers.get(k)
            if handler is not None:
                handler()

    def _set(self, k, v):
        if self.conn is not None:
            setattr(self.conn.ctx, k, v)

    def _gather_facts(self):
        res = self.conn.unsafe_run('set')
        if res is None:
            return None

        facts = {}
        for line in res.stdout.splitlines():
            try:
                k, v = line.split('=', 1)
            except ValueError:
                continue
            facts[k] = v

        self._set('facts', facts)
        self._set('is_windows', 'windows' in facts.get('OS', '').lower())
        self._set('is_linux', 'LANG' in facts)


def task(*sources, host_filter=None, **kwargs):
    helper = TaskHelper(**kwargs)
    inventory = load_inventory(*sources, host_filter=host_filter)
    cfg = fabric.Config(runtime_ssh_path=inventory.runtime_ssh_config_path)

    def decorator(func):
        @functools.wraps(func)
        def wrapper(ctx):
            hosts = []
            tasks = {}
            logs = {}
            labels = set()
            task_results = collections.defaultdict(dict)
            for i, target in enumerate(inventory.targets):
                host = AraHost.from_inventory_target(target)
                hosts.append(host)
                with LoggableConnection(ctx, config=cfg, target=target) as connection:
                    if isinstance(connection, (paramiko.ssh_exception.SSHException, OSError)):
                        tr = AraTaskResult.create_unexpected_exception_result(host, connection)
                        tasks[str(tr.lineno)] = AraTask.from_task_result(tr)
                        task_results[str(tr.lineno)][tr.host_key] = tr
                        continue

                    if helper.enabled:
                        helper.set_connection(connection)
                        helper.process()

                    try:
                        func(connection)
                    except Exception as e:
                        tr = AraTaskResult.create_unexpected_exception_result(host, e)
                        connection.task_results.append(tr)
                        if DEBUG:
                            raise

                if connection.logs:
                    logs[host.key] = connection.logs
                if connection.labels:
                    labels.update(connection.labels)

                for tr in connection.task_results:
                    if tr.lineno in tasks:
                        continue

                    # key must be a string because context data will be stored as string in
                    # fabric's DataProxy manages the context
                    tasks[str(tr.lineno)] = AraTask.from_task_result(tr)

                for tr in connection.task_results:
                    task_results[str(tr.lineno)][tr.host_key] = tr

            ctx.logs = logs
            ctx.labels = labels
            ctx.fabric_hosts = hosts
            ctx.fabric_tasks = tasks
            ctx.fabric_task_results = dictize(task_results)

        if DEBUG:
            pre_tasks = []
            post_tasks = [invoke.call(clean_operation, inventory=inventory)]
        else:
            pre_tasks = [invoke.call(create_playbook, fabfile_path=func.__code__.co_filename)]
            post_tasks = [
                append_user_logs,
                update_playbook_result,
                update_playbook_labels,
                invoke.call(clean_operation, inventory=inventory),
            ]
        return fabric.task(
            wrapper,
            klass=LoggableTask,
            pre=pre_tasks,
            post=post_tasks,
        )

    return decorator


@fabric.task
def create_playbook(ctx, fabfile_path):
    version = f'fabric-{fabric.__version__}'
    labels = list(set(filter(bool, [*os.getenv('LABELS', '').split(','), 'fabric'])))
    name = '/'.join(os.path.dirname(fabfile_path).split('/')[-2:])
    common_args = dict(name=name, ansible_version=version)
    args = dict(
        status='running',
        labels=labels,
        controller=username or hostname,
        started=tz_now(),
        path=fabfile_path,
    )
    res = client.get('/api/v1/playbooks', **common_args)
    if res['count'] == 0:
        ctx.playbook = client.post('/api/v1/playbooks', **common_args, **args)
    else:
        playbook_id = res['results'][0]['id']
        ctx.playbook = client.patch(f'/api/v1/playbooks/{playbook_id}', **args)

    common_args = dict(path=ctx.playbook['path'], playbook=ctx.playbook['id'])
    res = client.get('/api/v1/files', **common_args)
    with open(ctx.playbook['path'], 'r') as f:
        content = f.read()
    if res['count'] == 0:
        ctx.file = client.post('/api/v1/files', **common_args, content=content)
    else:
        file = res['results'][0]
        ctx.file = client.patch(f"/api/v1/files/{file['id']}", **common_args, content=content)

    ctx.play = client.post(
        '/api/v1/plays',
        name=os.getenv('COMMIT_TITLE'),
        status='running',
        uuid=str(uuid.uuid4()),
        playbook=ctx.playbook['id'],
        started=tz_now(),
    )


@fabric.task
def append_user_logs(ctx):
    if not ctx.logs:
        return

    _task = None
    results = {}
    hosts_by_key = {h.key: h for h in ctx.fabric_hosts}
    for hk in ctx.logs:
        logs = ctx.logs[hk]
        if not logs:
            continue

        if _task is None:
            _task = AraTask('log', 0, 'completed')
            ctx.fabric_tasks['0'] = _task

        host = hosts_by_key[hk]

        tr = AraTaskResult(host.host, host.port, 'log', 'log')
        tr.ended = tz_now()
        tr.status = 'ok'
        tr.content = {'logs': logs}
        tr.filename = ''
        tr.lineno = 0
        results[host.key] = tr

    if results:
        ctx.fabric_task_results['0'] = results


@fabric.task
def update_playbook_result(ctx):
    ctx.play = client.patch(
        f"/api/v1/plays/{ctx.play['id']}",
        status='completed',
        ended=tz_now(),
    )
    for host in ctx.fabric_hosts:
        ara_host = client.post(
            "/api/v1/hosts",
            playbook=ctx.playbook['id'],
            name=host.name,
            facts={'host': host.host},
        )
        host.id = ara_host['id']
        host.changed = ara_host['changed']
        host.failed = ara_host['failed']
        host.ok = ara_host['ok']

    common_args = dict(playbook=ctx.playbook['id'], play=ctx.play['id'])
    for i, lineno in enumerate(ctx.fabric_tasks):
        t: AraTask = ctx.fabric_tasks[lineno]
        ara_task = client.post(
            "/api/v1/tasks",
            name=f'{t.action}-{i + 1}',
            file=ctx.file['id'],
            **t.to_dict(),
            **common_args,
        )

        for host in ctx.fabric_hosts:
            try:
                tr = ctx.fabric_task_results[lineno][host.key]
            except KeyError:
                continue

            result_args = dict(host=host.id, task=ara_task['id'], **common_args)
            client.post("/api/v1/results", **tr.to_dict(), **result_args)
            if tr.status == 'failed':
                host.failed += 1
            elif tr.status == 'changed' or tr.status == 'ok':
                host.changed += 1
                host.ok += 1
            elif tr.status == 'unreachable':
                host.unreachable += 1

    for host in ctx.fabric_hosts:
        client.patch(
            f"/api/v1/hosts/{host.id}",
            changed=host.changed,
            failed=host.failed,
            ok=host.ok,
            unreachable=host.unreachable,
        )

    playbook_status = 'completed'
    if any(host.failed > 0 for host in ctx.fabric_hosts):
        playbook_status = 'failed'

    ctx.playbook = client.patch(
        f"/api/v1/playbooks/{ctx.playbook['id']}",
        status=playbook_status,
        ended=tz_now(),
    )


@fabric.task
def update_playbook_labels(ctx):
    pre_labels = set(map(lambda label: label['name'], ctx.playbook['labels']))
    if ctx.labels.difference(pre_labels):
        ctx.labels.update(pre_labels)
        ctx.playbook = client.patch(
            f"/api/v1/playbooks/{ctx.playbook['id']}",
            labels=list(ctx.labels),
        )


# noinspection PyUnusedLocal
@fabric.task
def clean_operation(ctx, inventory):
    try:
        os.remove(inventory.runtime_ssh_config_path)
    except OSError:
        pass
