import os
import gitlab
import argparse

from datetime import datetime
from prettytable import PrettyTable

"""
# listing the issues (all)
python3 gl_issue.py list -c all

# create issue
python3 gl_issue.py create -t "이슈만들기 테스트" -d "이슈를 빨리 닫아보셔요" -a jh -l sys -c jh

# remove all issues
python3 gl_issue.py remove
"""

# abbrv: [name, id]
MEMBERS = {
    'jh': ['Jinho Jung', 'jinho'],
    'gl': ['Geon-Young Lee', 'gylxor'],
    'hl': ['Hwiwon Lee', 'hwiwon'],
    'jc': ['Junsang Cheon', 'junsang'],
    'jj': ['Jinseok Jang', 'jinseok123'],
    'dk': ['Donghyun Kim', 'donghyun'],
    'th': ['Taejin Hwang', 'HwangTaeJin'],
    'hk': ['Heeyeon Kim', 'heeyeon'],
    'tk': ['Taehyung Kwon', 'taehyung'],
    'dy': ['Dohyun Yu', 'jtr9224'],
    'cw': ['Chisung Won', 'wonchisung'],
    'gs': ['Gijun Sung', 'crit3ri4'],
    'hj': ['Hyeongseok Jang', 'hyeongseok'],
    'kh': ['Kyungyong Han', 'kyungyong']
}

LABELS = {
    'sys': 'ch::system',
    'net': 'ch::network',
    'for': 'ch::forensic',
    'web': 'ch::web'
}

URL = 'http://gitlab.ls22lab.com'


def init_gitlab(url, token):
    gl = gitlab.Gitlab(url=url, private_token=token)
    return gl
    

class GitlabManager(object):
    def __init__(self, token):
        self.token = token
        self.gl = init_gitlab(URL, self.token)
        self.report = PrettyTable()

    def create_issue(self, title, desc, assignee, label, cc):
        project = self.gl.projects.get(2)

        if cc != 'none':
            desc_new = "%s\n\n/cc @%s" % (desc, MEMBERS[cc][1])
        else:
            desc_new = desc

        issue = project.issues.create(
            {
                'title': title,
                'description': desc_new,
                'labels': [LABELS[label]]
            }
        )

        user_id = self.gl.users.list(username=MEMBERS[assignee][1])[0].id
        issue.assignee_ids = [user_id]
        issue.save()

    def remove_all_issues(self):
        project = self.gl.projects.get(2)
        
        issues = project.issues.list()
        for issue in issues:
            project.issues.delete(issue.id)

    def show_projects(self):
        print(self.gl.projects.list())

    def show_issue_lists(self, cls):
        self.report.field_names = ['Num', 'Assignee', 'Team', 'State', 'Title', 'duration(H)', 'Closed Reason']
        self.report.align["Title"] = "l"
        self.report.align['Closed Reason'] = 'l'

        project = self.gl.projects.get(2)

        if cls == "open":
            issues = project.issues.list(state='opened')
        elif cls == "closed":
            issues = project.issues.list(state='closed')
        else:
            issues = project.issues.list()

        for i, issue in enumerate(issues):
            
            title = issue.title
            state = issue.state
            
            # get assignee
            if len(issue.assignees) > 0:
                assignee = issue.assignees[0]
                assignee_name = assignee['name']
            else:
                assignee_name = 'N/A'

            # get team
            if len(issue.labels) > 0:
                team = ','.join([x.split("::")[1] for x in issue.labels])
            else:
                team = "N/A"

            # get duration
            dt_obj = datetime.strptime(issue.created_at.split('.')[0], '%Y-%m-%dT%H:%M:%S')
            duration = datetime.now() - dt_obj
            duration = round(abs(duration.total_seconds() / 3600) ) - 8

            # get notes
            notes = issue.notes.list()
            note_body = ""
            for note in notes:
                if not note.body.startswith('assigned to'):
                    note_body += note.body.replace("\n", "") + " "
            if note_body == "":
                note_body = "N/A"
            self.report.add_row([i, assignee_name, team, state, title, duration, note_body])

        print(self.report)


def main():

    if "GITLAB_TOKEN" not in os.environ:
        print("You should export GITLAB_TOKEN") 
        exit(0)
    token = os.environ['GITLAB_TOKEN']

    parser = argparse.ArgumentParser(description='issue manager')    
    subparsers = parser.add_subparsers(title='arguments')

    lst = subparsers.add_parser('list', help='list opened issues', add_help=False)
    lst.add_argument("-c", "--class", dest="cls", type=str, default="open",
                                    required=False)
    lst.set_defaults(action='list')

    crt = subparsers.add_parser('create', help='list opened issues', add_help=False)
    crt.add_argument("-t", "--title", dest="title", type=str, required=True)
    crt.add_argument("-d", "--desc", dest="desc", type=str, required=True)
    crt.add_argument("-a", "--assignee", dest="assignee", type=str, required=True)
    crt.add_argument("-l", "--label", dest="label", type=str, required=True)
    crt.add_argument("-c", "--cc", dest="cc", type=str, required=False)
    crt.set_defaults(action='create')

    rm = subparsers.add_parser('remove', help='remove all issues', add_help=False)
    rm.set_defaults(action='remove')

    args = parser.parse_args()

    gm = GitlabManager(token)

    if args.action == 'list':
        gm.show_issue_lists(args.cls)
    elif args.action == 'create':
        if 'cc' in args:
            cc = args.cc
        else:
            cc = 'none'

        gm.create_issue(args.title, args.desc, args.assignee, args.label, cc)
    elif args.action == 'remove':
        gm.remove_all_issues()


if __name__ == "__main__":
    main()
