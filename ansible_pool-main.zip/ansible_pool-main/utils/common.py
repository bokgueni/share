import collections
import datetime
import inspect

import pytz

from config import config

DT_FMT = '%Y-%m-%d %H:%M'
DETAILED_DT_FMT = '%Y-%m-%d %H:%M:%S.%f'


def tz_now(as_str=True):
    tz = pytz.timezone(config.ARA_TIME_ZONE)
    dt = datetime.datetime.now(tz=tz)
    if as_str:
        return dt.strftime(DETAILED_DT_FMT)
    return dt


def fmt_dt(dt: datetime.datetime, fmt=DETAILED_DT_FMT):
    return dt.strftime(fmt)


def get_parent_frame(*excludes):
    stack = inspect.stack()
    for frame in stack:
        if frame.filename != __file__ and frame.filename not in excludes:
            return frame
    return None


def dictize(d):
    if isinstance(d, collections.defaultdict):
        d = {k: dictize(v) for k, v in d.items()}
    return d
