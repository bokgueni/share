from collections import abc
from typing import Optional

import redis

from config import config

DEFAULT_DB = 0
WEBHOOK_DB = 1


def _decode(v, decode: bool):
    if not decode:
        return v

    if isinstance(v, bytes):
        return v.decode()
    elif isinstance(v, set):
        return set(map(lambda x: x.decode(), v))
    elif isinstance(v, list):
        return list(map(lambda x: x.decode(), v))
    elif isinstance(v, dict):
        for k, v in v.items():
            v[k] = v.decode()
        return v


def create_redis_client(db=DEFAULT_DB, client: Optional[redis.Redis] = None):
    if client is not None:
        return client
    return redis.Redis(config.redis_endpoint, config.REDIS_PORT, db)


def load(db, k, client: Optional[redis.Redis] = None, decode=True):
    with create_redis_client(db, client=client) as cli:
        typ = cli.type(str(k)).decode()
        if typ == 'string':
            return _decode(cli.get(k), decode)
        elif typ == 'set':
            return _decode(cli.smembers(k), decode)
        elif typ == 'list':
            return _decode(cli.lrange(k, 0, -1), decode)
        elif typ == 'hash':
            return _decode(cli.hgetall(k), decode)
        elif typ == 'none':
            return None
        raise ValueError(f'{typ} is not supported type.')


def save(db, k, v, client: Optional[redis.Redis] = None):
    if v is None:
        return None

    with create_redis_client(db, client=client) as cli:
        k = str(k)
        if isinstance(v, str):
            return cli.set(k, v)
        elif isinstance(v, set):
            return cli.sadd(k, *v)
        elif isinstance(v, (list, tuple, abc.Iterable)):
            return cli.rpush(k, *v)
        elif isinstance(v, dict):
            return cli.hmset(k, v)
        raise ValueError(f'{type(v)} is not supported type.')


def delete(db, k, client: Optional[redis.Redis] = None):
    with create_redis_client(db, client=client) as cli:
        cli.delete(k)
