def validate_plugin_args(kwargs, valid_args, required_args):
    task_opts = frozenset(kwargs.keys())
    bad_opts = task_opts.difference(valid_args)
    if bad_opts:
        raise ValueError(f"Invalid options: {','.join(list(bad_opts))}")

    empty_opts = required_args.difference(task_opts)
    if empty_opts:
        raise ValueError(f"Required options are empty: {','.join(empty_opts)}")
