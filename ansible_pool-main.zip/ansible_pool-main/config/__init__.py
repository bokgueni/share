import configparser
import glob
import importlib
import os
import pathlib
import re
import socket
from urllib import parse

try:
    from config import secret  # noqa
except ImportError:
    secret = object()

__all__ = (
    'config',
)


class Config:
    PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
    SERVICE_DIR = PROJECT_ROOT / 'services'
    WEBHOOK_DIR = PROJECT_ROOT / 'webhook'
    CONFIG_DIR = PROJECT_ROOT / 'config'
    DEFAULT_TIMEZONE = 'Europe/Tallinn'
    DEFAULT_ENV = os.environ.get('ENV', 'fam')

    ANSIBLE_CONFIG_TEMPLATE_PATH = CONFIG_DIR / 'ansible.cfg.template'
    ANSIBLE_CONFIG_PATH = CONFIG_DIR / 'ansible.cfg'

    DEFAULT_SSH_TIMEOUT = 30
    DEFAULT_SSH_KEY_PATH = CONFIG_DIR / 'default.priv'
    DEFAULT_SSH_PORT = 22
    DEFAULT_SSH_USER = 'root'

    GITLAB_SCHEME = 'http'
    GITLAB_HOST = 'gitlab.begauto.com'
    GITLAB_PORT = 80
    GITLAB_SSH_PORT = 22
    GITLAB_ACCESS_TOKEN_ID = 'automation'
    GITLAB_ACCESS_TOKEN = os.environ.get(
        'GITLAB_ACCESS_TOKEN',
        getattr(secret, 'GITLAB_ACCESS_TOKEN', None),
    )
    GITLAB_ADMIN_READONLY_TOKEN = os.environ.get(
        'GITLAB_ADMIN_READONLY_TOKEN',
        getattr(secret, 'GITLAB_ADMIN_READONLY_TOKEN', None),
    )

    ARA_API_HOST = os.environ.get('ARA_API_HOST', '220.72.26.110')
    ARA_API_PORT = int(os.environ.get('ARA_API_PORT', 8000))
    ARA_TIME_ZONE = DEFAULT_TIMEZONE

    # commit title rule
    # Example: op-fabric-10001/fabric-test or op-ansible-10001/ansible-test or op-ansible-100002
    AUTOMATION_WEBHOOK_RULE = re.compile(r'op-(?P<type>ansible|fabric)-(?P<no>\d+)/?(?P<desc>.*)')
    AUTOMATION_WEBHOOK_TOKEN = ''
    AUTOMATION_WEBHOOK_PORT = 8001

    MINIO_SERVER_HOST = os.environ.get('MINIO_SERVER_HOST', '220.72.26.110')
    # After changing port number, you must update minio service nginx.conf
    MINIO_SERVER_PORT = int(os.environ.get('MINIO_SERVER_PORT', 9000))
    MINIO_CONSOLE_PORT = int(os.environ.get('MINIO_CONSOLE_PORT', 34081))
    MINIO_ROOT_USER = os.environ.get('MINIO_ROOT_USER', 'beg_secu')
    MINIO_ROOT_PASSWORD = os.environ.get('MINIO_ROOT_PASSWORD', 'dpsjwlqhdks!@')
    MINIO_DEFAULT_BUCKET_NAME = 'ls24-beg-data'
    MINIO_DEBUG_BUCKET_NAME = 'debug'

    REDIS_PORT = 6379

    ISSUE_NOTIFICATION_TOKEN = ''
    ISSUE_MAN_SLACK_TOKEN = os.environ.get(
        'ISSUE_MAN_SLACK_TOKEN',
        getattr(secret, 'ISSUE_MAN_SLACK_TOKEN', None),
    )
    NOTIFICATION_WEBHOOK_PORT = int(os.environ.get('NOTIFICATION_WEBHOOK_PORT', 8004))

    SLACK_WEBHOOK_URL = ''  # noqa
    AUTOMATION_SLACK_ADMIN = ''
    GITLAB_SLACK_USERS_MAP = {
        
    }
    GITLAB_GROUP_SLACK_CHANNEL_MAP = {
        }

    def __init__(self):
        self.override_config(self.env)
        self.override_config('local')

    @property
    def env(self):
        return os.getenv('ENV', self.DEFAULT_ENV)

    @property
    def host(self):
        u = parse.urlparse(f'{self.GITLAB_SCHEME}://{self.GITLAB_HOST}')
        return '.'.join(u.hostname.split('.')[-2:])

    @property
    def inventory_dir(self):
        return self.PROJECT_ROOT / 'inventory' / self.env

    @property
    def gitlab_project_url(self):
        return (
            f'{config.GITLAB_SCHEME}'
            f'://{config.GITLAB_ACCESS_TOKEN_ID}:{config.GITLAB_ACCESS_TOKEN}'
            f'@{config.GITLAB_HOST}:{config.GITLAB_PORT}/operator/automation.git'
        )

    @property
    def gitlab_endpoint(self):
        if config.GITLAB_PORT in [80, 443]:
            return f'{config.GITLAB_SCHEME}://{config.GITLAB_HOST}'
        return f'{config.GITLAB_SCHEME}://{config.GITLAB_HOST}:{config.GITLAB_PORT}'

    @property
    def ansible_ara_endpoint(self):
        return f'http://{self.ARA_API_HOST}:{self.ARA_API_PORT}'

    @property
    def minio_endpoint(self):
        return f'http://{self.MINIO_SERVER_HOST}:{self.MINIO_SERVER_PORT}'

    @property
    def minio_raw_endpoint(self):
        host = socket.gethostbyname(self.MINIO_SERVER_HOST)
        return f'http://{host}:{self.MINIO_SERVER_PORT}'

    @property
    def redis_endpoint(self):
        try:
            content = open('/proc/1/cgroup', 'r').read()
        except OSError:
            return '127.0.0.1'
        return 'cache' if '/docker' in content else '127.0.0.1'

    def override_config(self, env: str):
        try:
            env_config = importlib.__import__(f'config.{env}', fromlist=['*'])
        except ImportError:
            return

        for attr in dir(env_config):
            if attr.startswith('_'):
                continue
            setattr(self, attr, getattr(env_config, attr))

    def assert_service_config(self):
        assert self.GITLAB_HOST, "GITLAB_HOST is not set."
        assert self.GITLAB_ACCESS_TOKEN, "GITLAB_ACCESS_TOKEN is not set."
        assert self.DEFAULT_SSH_KEY_PATH.exists()

    def update_ansible_config(self):
        assert self.ANSIBLE_CONFIG_TEMPLATE_PATH.exists()
        assert self.DEFAULT_SSH_KEY_PATH.exists()

        from ara.setup import ansible

        cfg = configparser.ConfigParser()
        cfg.read(self.ANSIBLE_CONFIG_TEMPLATE_PATH.as_posix())

        action_plugins = ':'.join([
            ansible.action_plugins,
            (self.PROJECT_ROOT / 'plugins' / 'action').as_posix(),
        ])

        cfg.set('defaults', 'action_plugins', action_plugins)
        cfg.set('defaults', 'lookup_plugins', ansible.lookup_plugins)

        inventories = []
        for inventory_path in glob.glob(f'{self.inventory_dir}/*.yml'):
            inventories.append(inventory_path)
        cfg.set('defaults', 'inventory', ','.join(inventories))
        cfg.set('defaults', 'private_key_file', self.DEFAULT_SSH_KEY_PATH.as_posix())
        cfg.set('defaults', 'timeout', str(self.DEFAULT_SSH_TIMEOUT))

        cfg.set('defaults', 'forks', str(os.cpu_count() * 2))

        ssh_config_path = config.CONFIG_DIR / 'ssh.cfg'
        cfg.add_section('connection')
        cfg.set('connection', 'ssh_args', f'-F {ssh_config_path.as_posix()}')

        with self.ANSIBLE_CONFIG_PATH.open('w') as f:
            f.write('; Generated by manage.py\n')
            cfg.write(f)


config = Config()
