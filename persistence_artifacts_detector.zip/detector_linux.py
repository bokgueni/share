import re
import os, os.path

import linux_common as cm
from known_payloads import *


def check_setuid_binary():
  print("[*] Check: Setuid binaries.")

  command = 'find / -perm -4000'
  result = cm.run_command(command)

  for x in result:
    cm.write_log(f"[+] Found (Setuid binary): {x}")


def check_crontab():
  print("[*] Check: Crontab.")

  for cron_path in LINUX_CRONTAB_PATH:
    for task in os.listdir(cron_path):
      if cm.filter_path(task):
        continue

      full_path = os.path.join(cron_path, task)
      cm.write_log(f"[+] Found (Crontab): {full_path}")


def check_service():
  print("[*] Check: Services.")

  for service_dir in LINUX_SERVICE_PATH:
    if not os.path.isdir(service_dir):
      continue

    for root_dir, dirs, files in os.walk(service_dir):
      if len(files) == 0:
        continue

      for file in files:
        name, ext = os.path.splitext(file)
        if ext == ".service":
          service_path = os.path.join(root_dir, file)
          cm.write_log(f"[+] Found (Service): {service_path}")


def check_ld_hijacking():
  print("[*] Check: Dynamic Linker Hijacking.")
  target = "/etc/ld.so.preload"

  if os.path.isfile(target):
    cm.write_log(f"[+] Found ld file: {target}")


if __name__ == "__main__":
  g = dict(globals())
  for k in g:
    if k[:5] == "check" and callable(g[k]):
      print("="*57)
      g[k]()  # function()