import linux_common as cm


LINUX_CRONTAB_PATH = (
  "/etc/cron.d",
  "/etc/cron.daily",
  "/etc/cron.hourly",
  "/etc/cron.monthly",
  "/etc/cron.weekly"
)

LINUX_SERVICE_PATH = [
  "/usr/lib/systemd/system",
  "/etc/systemd/system",
  "{user_path}/.config/systemd/user"
]

for idx, service_dir in enumerate(LINUX_SERVICE_PATH):
  if '{user_path}' in service_dir:
    del LINUX_SERVICE_PATH[idx]
    for user_path in cm.USER_PATH:
      LINUX_SERVICE_PATH.append(service_dir.format(user_path=user_path))