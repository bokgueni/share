import re
import winreg
import os, os.path
import xml.etree.ElementTree as ET

import pprint
import win_common as cm
from known_paths import *


def OpenKeyEx(hive, key):
  try:
    return winreg.OpenKeyEx(hive, key)
  except:
    return ()


def QueryValueEx(hkey, value_name):
  try:
    return winreg.QueryValueEx(hkey, value_name)
  except:
    return ()


def check_protection():
  """
    Disabled windows defender & Firewall
  """

  def _detect(REG_KNOWN_PATHS, changed_value):
    for hive, reg_key, reg_val in REG_KNOWN_PATHS:
      hkey = OpenKeyEx(hive, reg_key)
      if not hkey:
        continue

      value_info = QueryValueEx(hkey, reg_val)
      if not value_info:
        continue

      value_data = value_info[-1]
      if value_data == changed_value:
        log = f"[+] Found (Registry): {reg_key}\\{reg_val}"
        cm.write_log(log)

  print("[*] Check: Windows defender configuration.")
  _detect(REG_WINDOWS_DEFENDER, 1)

  print("[*] Check: Windows defender's real-protection configuration.")
  _detect(REG_WINDOWS_DEFENDER_RT_PROTECTION1, 1)
  _detect(REG_WINDOWS_DEFENDER_RT_PROTECTION2, 2)

  print("[*] Check: Windows Firewall configuration.")
  _detect(REG_WINDOWS_FIREWALL, 0)


def check_registry():
  print("[*] Check: Registry - Autostart extensibility point (ASEP).\n")

  def _check_image_path(source, options=None):
    (ar_list, ar_dict) = cm.run_autoruns(options)

    for image_path in ar_dict.keys():
      if image_path == "":
        continue

      env_path = cm.env2path(image_path)
      for file_path in env_path:
        if not os.path.isfile(file_path):
          continue

        cm.write_all(f"{source}: {file_path}")
        file_object = open(file_path, "rb")

        if cm.check_susp(file_object):
          cm.write_log(f"[+] Found {source}: {file_path}")

  def _check_image_and_launch_string(source, options=None):
    (ar_list, ar_dict) = cm.run_autoruns(options)

    conv_path_list = []
    for rpath, image_path, run_string in ar_list:
      if image_path != "":
        for _ in cm.env2path(image_path):
          conv_path_list.append(_.lower())

      if run_string != "":
        epos = run_string[1:].find('"')
        if epos != -1:
          tmp_run =  run_string[:epos + 1].strip('"').split(" /")[0]
          for _ in cm.env2path(tmp_run):
            conv_path_list.append(_.lower())

        else:
          tmp_run = run_string.split(" /")[0]

          rundll_pos = tmp_run.find("rundll32.exe ")
          if rundll_pos != -1:
            tmp_args_dll = tmp_run[rundll_pos+13:]
            tmp_run = ','.join(tmp_args_dll.split(",")[:-1])

          for _ in cm.env2path(tmp_run):
            r = re.findall(
              pattern=r'([a-zA-Z]:\\(?:.*?\\)*.*)',
              string=_
            )
            if len(r) == 0:
              continue

            tmp = r[0]
            r = re.findall(
              pattern=r'.[a-zA-Z0-9]*\ ([-]{1,2}[a-zA-Z0-9]*)',
              string=tmp
            )

            if len(r) != 0:
              fpos = tmp.find(r[0])
              conv_path = tmp[:fpos]
            else:
              conv_path = tmp
            conv_path_list.append(conv_path.strip().lower())

    for file_path in sorted(list(set(conv_path_list))):
      if not os.path.isfile(file_path):
        continue

      cm.write_all(f"{source}: {file_path}")
      file_object = open(file_path, "rb")
      if cm.check_susp(file_object):
        cm.write_log(f"[+] Found {source}: {file_path}")

  print("[*] Check: Registry - Boot execute.")
  _check_image_path("(Boot execute)", 'b')

  print("[*] Check: Registry - Codecs.")
  _check_image_path("(Codecs)", 'c')

  print("[*] Check: Registry - Appinit DLLs.")
  _check_image_path("(Appinit DLLs)", 'd')

  print("[*] Check: Registry - Explorer addons.")
  _check_image_path("(Explorer addons)", 'e')

  print("[*] Check: Registry - Image hijacks.")
  _check_image_path("(Image hijacks)", 'h')

  print("[*] Check: Registry - Internet Explorer addons.")
  _check_image_path("(Internet Explorer addons)", 'i')

  print("[*] Check: Registry - Known DLLs.")
  _check_image_path("(Known DLLs)", 'k')

  print("[*] Check: Registry - Logon startups.")
  _check_image_and_launch_string("(Logon startups)", 'l')

  print("[*] Check: Registry - WMI entries.")
  _check_image_path("(WMI entries)", 'm')

  print("[*] Check: Registry - Winsock protocol and network providers.")
  _check_image_path("(Winsock protocol and network providers)", 'n')

  print("[*] Check: Registry - Office addins.")
  _check_image_path("(Office addins)", 'o')

  print("[*] Check: Registry - Printer monitor DLLs.")
  _check_image_path("(Printer monitor DLLs)", 'p')

  print("[*] Check: Registry - Autostart services and non-disabled drivers.")
  _check_image_path("(Autostart services and non-disabled drivers)", 's')

  print("[*] Check: Registry - Winlogon entries.")
  _check_image_path("(Winlogon entries)", 'w')


def check_files():
  def _check_folder(detection_info, source=""):
    for dir_path, extension in detection_info:
      path_list = cm.env2path(dir_path)
      for _path in path_list:
        if not os.path.isdir(_path):
          continue

        for file_name in os.listdir(_path):
          file_path = os.path.join(_path, file_name)
          (fn, ext) = os.path.splitext(file_path)
          ext = ext[1:].lower()

          if not os.path.isfile(file_path):
            continue

          cm.write_all(f"{source}: {file_path}")
          if extension == "*" or ext in extension.split("|") or file_name.lower() == extension.lower():
            file_object = open(file_path, "rb")

            if cm.check_susp(file_object):
              cm.write_log(f"[+] Found {source}: {file_path}")

  def _verify_file(detection_info, source=""):
    for dir_path, target in detection_info:
      path_list = cm.env2path(dir_path)

      for tgt in target.split("|"):
        for _path in path_list:
          full_path = os.path.join(_path, tgt)

          if not os.path.isfile(full_path):
            continue

          cm.write_all(f"{source}: {full_path}")
          file_object = open(full_path, "rb")
          if cm.is_cmd(file_object):
            cm.write_log(f"[+] Found {source}: {full_path}")

  def _parse_tasks(detction_info, source=""):
    namespace = {'ns': 'http://schemas.microsoft.com/windows/2004/02/mit/task'}
    task_list = []

    for dir_path in detction_info:
      path_list = cm.env2path(dir_path)

      for task_path in path_list:
        for root_dir, dirs, files in os.walk(task_path):
          if len(files) == 0:
            continue

          for file_path in files:
            full_path = os.path.join(root_dir, file_path)

            try:
              tree = ET.parse(full_path)
            except:
              continue

            root = tree.getroot()
            actions_tag = root.find('ns:Actions', namespace)
            command_tag = None
            for x in actions_tag[0]:
              if x.tag.find("Command") != -1:
                command_tag = x

            if not (command_tag is None):
              run_path = command_tag.text
              task_list.append(run_path)

    run_path_list = []
    for task_path in list(set(task_list)):
      path_list = cm.env2path(task_path.replace("\"", "").replace("'", ""))

      for _ in path_list:
        if not os.path.isfile(_):
          continue

        run_path_list.append(_)

    for run_path in list(set(run_path_list)):
      cm.write_all(f"{source}: {run_path}")
      file_object = open(run_path, "rb")
      if cm.check_susp(file_object):
        cm.write_log(f"[+] Found {source}: {run_path}")

  print("[*] Check: Files - Startup folder (Program).")
  _check_folder(FILE_WINDOWS_STARTUP_PROGRAMS, "(Startup folder)")

  print("[*] Check: Files - Startup folder (MS Office).")
  _check_folder(FILE_WINDOWS_STARTUP_OFFICE, "(Startup folder: MS Office)")

  print("[*] Check: Files - DLL Hijacking via osk.")
  _check_folder(FILE_WINDOWS_DLL_HIJACKING_OSK, "(Backdoor via OSK)")

  print("[*] Check: Files - Password reset backdoors.")
  _verify_file(FILE_WINDOWS_BINARY_REPLACEMENT, "(Binary Replacement)")

  print("[*] Check: Files - Scheduled tasks.")
  _parse_tasks(FILE_WINDOWS_SCHEDULED_TASKS, "(Scheduled Tasks)")


if __name__ == "__main__":
  g = dict(globals())

  for k in g:
    # if k[:7] == "check_r" and callable(g[k]):   # Debug
    if k[:5] == "check" and callable(g[k]):
      print("="*57)
      g[k]()  # function()