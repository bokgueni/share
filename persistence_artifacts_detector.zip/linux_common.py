import subprocess


def write_log(log):
  print(log)
  open(LOGFILE, "a").write(log+"\n")


def run_command(command, onfilter=True):
  result = []
  proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE)

  while proc.poll() is None:
    out = proc.stdout.readline().decode().strip()

    if filter_path(out) and onfilter:
      continue
    result.append(out)
  return result[:-1]


def filter_path(path):
  white_list = (
    "/snap/core",
    "/var/lib/docker/overlay2/",
  )

  if len(path) == 0:
    return True

  if path[0] == ".":
    return True

  for _ in white_list:
    if _ in path:
      return True
  return False


def get_user_list():
  user_dict = {
    "root": "/root"
  }

  result = run_command('ls /home', onfilter=False)
  for user in result:
    user_dict[user] = f"/home/{user}"

  return user_dict


LOGFILE    = "./detection_result.log"
USER_DICT = get_user_list()
USER_LIST = USER_DICT.keys()
USER_PATH = USER_DICT.values()