import re
import csv
import yara
import magic
import pefile
import platform
import requests
import subprocess
import os, os.path
import win32com.client

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from asn1crypto import cms

import pickle
import known_paths

from pprint import pprint


def run_autoruns(options="l"):
  if platform.machine().endswith('64'):
    command = ['./res/autorunsc64.exe', '-accepteula', '-c', '-a', options]
  else:
    command = ['./res/autorunsc.exe', '-accepteula', '-c', '-a', options]

  proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
  (_o, _e) = proc.communicate()
  result = _o.decode("UTF-16LE").splitlines()[5:]
  autoruns_csv = csv.DictReader(result, delimiter=',', quotechar='"')

  result_list = []
  result_dict = {}
  for row in autoruns_csv:
    tmp = (row['Entry Location'], row['Image Path'].lower(), row['Launch String'].lower())

    result_dict = add_list_to_dict(result_dict, tmp[1], (tmp[0], tmp[2]))
    result_list.append(tmp)

  return sorted(list(set(result_list))), result_dict


def is_cmd(file_object):
  str1 = b"Microsoft Corporation. All rights reserved."
  str2 = b"cmd.exe"

  data = file_object.read()
  if data.find(str1) != -1 and data.find(str2) != -1:
    return True
  return False


def check_susp(file_object):
  def import_yara_rules():
    yara_path = "./yara_rules"

    filepaths = {}
    for file_name in os.listdir("./yara_rules"):
      rule_path = os.path.join(yara_path, file_name)
      name_space = os.path.splitext(file_name)[0]
      filepaths[name_space] = rule_path

    return yara.compile(filepaths=filepaths)

  def get_cert_from_pe(file_data):
    """
    # Ref: https://stackoverflow.com/a/59125323
    """
    pe = pefile.PE(data=file_data)
    sigoff = pe.OPTIONAL_HEADER.DATA_DIRECTORY[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_SECURITY"]].VirtualAddress
    siglen = pe.OPTIONAL_HEADER.DATA_DIRECTORY[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_SECURITY"]].Size
    pe.close()

    if siglen == 0:
      return []

    thesig = file_data[sigoff:sigoff+siglen]
    signature = cms.ContentInfo.load(thesig[8:])

    result = []
    for cert in signature["content"]["certificates"]:
      parsed_cert = x509.load_der_x509_certificate(cert.dump(), default_backend())

      cert_issuer_info = parsed_cert.issuer.rfc4514_string().split(",")

      for _ in cert_issuer_info:
        if _.find("CN=") != -1:
          cn = _[3:]
          result.append(parse_cn(cn))
    return result

  def check_pe_signature(pe_cert_list):
    if not pe_cert_list:
      return False

    for pe_cert in pe_cert_list:
      if pe_cert in TRUSTED_CN_LIST:
        return True
    return False

  def detect_cmd_tool(run_path):
    cmd_tools = ['powershell', 'comspec', 'cmd.exe']
    for cmd in cmd_tools:
      if run_path.find(cmd) != -1:
        return True
    return False

  filepath = file_object.name.lower()
  if filepath in known_paths.WINDOWS_PATH_WHITE_LIST:
    return False

  self_func = globals()['check_susp']
  buffer   = file_object.read()

  mime_type = magic.from_buffer(buffer, mime=True)
  yara_rule = import_yara_rules()

  if mime_type[:4] == "text":
    r = yara_rule.match(data=buffer)
    if r:
      return True

  if mime_type == "application/x-dosexec":
    cert_list = get_cert_from_pe(buffer)
    if not check_pe_signature(cert_list):
      return True

  if buffer[:8] == b"\x4C\x00\x00\x00\x01\x14\x02\x00":
    shortcut = WIN32SHELL.CreateShortCut(file_object.name)
    run_path = shortcut.Targetpath

    if detect_cmd_tool(run_path):
      write_log(f"[+] Found (From shortcut): {run_path} {shortcut.Arguments}")
      return True

    if self_func(open(run_path, "rb")):
      write_log(f"[+] Found (From shortcut): {run_path}")
      return True


def env2path(path):
  result = []

  pattern = "%([a-zA-Z]*)%"
  r = re.match(pattern, path)
  if r is None:
    return [path]

  env_var = r.groups()[0]
  env_var = env_var.lower()
  for key in ENV.keys():
    lkey = key.lower()
    if env_var == lkey:
      _env_key_list = ENV[key]
      key32 = key + '(x86)'

      if not ENV.get(key32) is None:
        _env_key_list.extend(ENV.get(key32))

      for env_path in _env_key_list:
        join_path = os.path.join(env_path, path[len(r[0])+1:])
        result.append(join_path)
      return result
  raise Exception(f"No env variables: {r[0]}")


def add_list_to_dict(_dict, k, v):
  if k in _dict.keys():
    _dict[k].append(v)
  else:
    _dict[k] = [v]
  return _dict


def parse_cn(cn):
  r = re.findall(pattern="20[0-9].*", string=cn.split(" ")[-1])
  if r:
    tmp = ' '.join(cn.split(" ")[:-1])
    if tmp.find(" -") != -1:
      result = tmp.split(" -")[0]
    else:
      result = tmp
  else:
    result = ' '.join(cn.split(" "))
  return result


def get_trusted_cn_list():
  def download_trusted_cert_csv():
    url = "https://ccadb-public.secure.force.com/microsoft/IncludedCACertificateReportForMSFTCSV"
    res = requests.get(url)

    return res.content.decode()

  trusted_cert_csv = download_trusted_cert_csv()
  csvfile = csv.DictReader(trusted_cert_csv.splitlines(), delimiter=',', quotechar='"')

  result = []
  for row in csvfile:
    cn = row['CA Common Name or Certificate Name']
    result.append(parse_cn(cn))

  return list(set(result))


def get_env_variables():
  def filter_name(name):
    name = name.lower()
    if name == "desktop.ini":
      if name in EXCEPT_NAMES:
        return False
    return True

  result = {}
  com_env = ['ALLUSERSPROFILE', 'CommonProgramFiles', 'CommonProgramFiles(x86)', 'CommonProgramW6432', 'ProgramData',
             'ProgramFiles', 'ProgramFiles(x86)', 'ProgramW6432', 'DriverData', 'SystemRoot', 'SystemDrive', 'windir']
  for _ in com_env:
    result = add_list_to_dict(result, _, os.environ[_])

  result['TEMP'] = [os.path.join(result['SystemRoot'][0], "TEMP")]
  result['TMP']  = [os.path.join(result['SystemRoot'][0], "TEMP")]

  user_dir = os.path.join(result['SystemDrive'][0], "\\Users")
  user_env = {
    'APPDATA': '{user_profile}\\AppData\\Roaming',
    'HOMEPATH': '{user_profile}',
    'LOCALAPPDATA': '{user_profile}\\AppData\\Local',
    'USERPROFILE': '{user_profile}',
    'TEMP': '{user_profile}\\AppData\\Local\\Temp',
    'TMP': '{user_profile}\\AppData\\Local\\Temp'
  }

  for user in os.listdir(user_dir):
    if filter_name(user):
      user_profile = os.path.join(user_dir, user)
      for u_env in user_env:
        dir_path = user_env[u_env].format(user_profile=user_profile)
        add_list_to_dict(result, u_env, dir_path)

  return result


def write_log(log):
  print(log)
  open(LOGFILE, "a").write(log+"\n")


def write_all(log):
  open(PROCESS_LOG, "a").write(log+"\n")


LOGFILE     = "./detection_result.log"
PROCESS_LOG = "./all_result.log"
EXCEPT_NAMES = ["All Users", "Default User", "desktop.ini"]
ENV = get_env_variables()
TRUSTED_CN_LIST = get_trusted_cn_list()
WIN32SHELL = win32com.client.Dispatch("WScript.Shell")