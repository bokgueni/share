Persistence (침해지속) 흔적 탐지 스크립트

1. 설명
	운영체제에 기록된 Persistence 흔적을 탐지하는 스크립트 입니다. 탐지를 지원하는 운영체제는 다음과 같습니다.
	- Windows
	  - After Windows 7
	  - Windows Server
	- Linux (보완사항 많음)
	  - Ubuntu
	  - CentOS
	  - FreeBSD

2. 준비 사항
	- Python 3.7 이상
	- PIP 설치

3. 설치
3.1. 파일 다운로드
	- 방법1 (Github)
		git clone https://github.com/ls22mnd/forensics.git
	- 방법2 (일반 다운로드)
		Repository > Code > Download

3.2. 외부 라이브러리 설치
	- Windows
		pip install -r requirements_win.txt
	- Linux
		pip3 install -r requirements_linux.txt

4. 컴파일 (선택 사항)
	- 하나의 실행 파일로 만들고 싶으면 진행. (Windows only)
  		./compile_script.bat

5. 사용
5.1. 실행
	- Windows Persistence 흔적 탐지
		python detector_windows.py
	- Linux Persistence 흔적 탐지
		python detector_linux.py

5.2. 결과 확인
	- 실행 로그는 콘솔 화면에서 출력되며, 따로 파일 형태로 기록되지 않습니다.
	- 탐지 결과는 실행 경로에 기록된 `detection_result.log` 를 통해서 확인할 수 있습니다.